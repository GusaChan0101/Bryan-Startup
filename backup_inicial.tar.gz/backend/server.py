from fastapi import FastAPI, APIRouter, HTTPException, Depends, status, Header
from fastapi.responses import StreamingResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict, EmailStr
from typing import List, Optional
import uuid
from datetime import datetime, timezone, timedelta
import bcrypt
import jwt
from emergentintegrations.llm.chat import LlmChat, UserMessage
import io
import json
import re

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# Safe env reads (won't crash at import if missing; adjust in production)
mongo_url = os.environ.get('MONGO_URL', '')
db_name = os.environ.get('DB_NAME', 'preparo_db')

# MongoDB connection
client = AsyncIOMotorClient(mongo_url) if mongo_url else AsyncIOMotorClient()
db = client[db_name]

# JWT Configuration
SECRET_KEY = os.environ.get('JWT_SECRET', 'your-secret-key-change-in-production')
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24 * 7

# Emergent LLM Key
EMERGENT_LLM_KEY = os.environ.get('EMERGENT_LLM_KEY')

# Admin email
ADMIN_EMAIL = 'bryan.imperador2008@gmail.com'

# Profanity filter (uses word boundaries)
BAD_WORDS = ['porra', 'merda', 'caralho', 'puta', 'fdp', 'vsf', 'cu', 'buceta', 'piroca', 'cacete']
_bad_word_patterns = [re.compile(r'\b' + re.escape(w) + r'\b', flags=re.IGNORECASE) for w in BAD_WORDS]

def has_profanity(text: str) -> bool:
    if not text:
        return False
    for pat in _bad_word_patterns:
        if pat.search(text):
            return True
    return False

def is_admin(user) -> bool:
    if not user:
        return False
    return user.get('is_admin', False) or user.get('email', '').lower() == ADMIN_EMAIL.lower()

# Create the main app
app = FastAPI()
api_router = APIRouter(prefix="/api")

# ============ MODELS ============

class User(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    email: EmailStr
    name: str
    avatar: Optional[str] = None
    bio: Optional[str] = None
    is_admin: bool = False
    followers: List[str] = Field(default_factory=list)
    following: List[str] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class UserCreate(BaseModel):
    email: EmailStr
    password: str
    name: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserUpdate(BaseModel):
    name: Optional[str] = None
    avatar: Optional[str] = None
    bio: Optional[str] = None

class Token(BaseModel):
    access_token: str
    token_type: str
    user: User

class Lesson(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    day: int
    title: str
    detailed_content: str
    questions: List[dict]

class StudyPlan(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: Optional[str] = None
    subject: str
    exam_date: str
    daily_hours: int
    difficulty_level: str
    banca: str
    escolaridade: str
    finalidade: str
    lessons: List[Lesson] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class StudyPlanCreate(BaseModel):
    subject: str
    exam_date: str
    daily_hours: int
    difficulty_level: str
    banca: str
    escolaridade: str
    finalidade: str

class LessonProgress(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    plan_id: str
    lesson_id: str
    completed: bool = False
    attempts: int = 0
    score: Optional[int] = None
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class LessonAnswer(BaseModel):
    lesson_id: str
    answers: List[dict]

class Post(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    user_name: str
    user_avatar: Optional[str] = None
    content: str
    image: Optional[str] = None
    likes: List[str] = Field(default_factory=list)
    comments_count: int = 0
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class PostCreate(BaseModel):
    content: str
    image: Optional[str] = None

class Comment(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    post_id: str
    user_id: str
    user_name: str
    user_avatar: Optional[str] = None
    content: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class CommentCreate(BaseModel):
    content: str

class Group(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    description: str
    concurso: str
    members: List[str] = Field(default_factory=list)
    created_by: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class GroupCreate(BaseModel):
    name: str
    description: str
    concurso: str

class AppConfig(BaseModel):
    pix_key: Optional[str] = None
    pix_qr_code: Optional[str] = None

# ============ AUTH HELPERS ============

def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    # PyJWT handles datetime objects for exp in recent versions
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def verify_token(token: str):
    try:
        return jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None

async def get_current_user(token: Optional[str] = None):
    """
    token: raw token string or "Bearer <token>".
    Returns user dict from DB or None.
    """
    if not token:
        return None

    # accept "Bearer <token>"
    if token.startswith("Bearer "):
        token = token.split(" ", 1)[1]

    payload = verify_token(token)
    if not payload:
        return None

    sub = payload.get("sub")
    if not sub:
        return None

    user = await db.users.find_one({"id": sub}, {"_id": 0})
    if not user:
        return None

    # convert created_at to datetime if stored as ISO string
    if isinstance(user.get('created_at'), str):
        try:
            user['created_at'] = datetime.fromisoformat(user['created_at'])
        except Exception:
            # fallback: leave as string
            pass

    return user

# ============ AUTH ROUTES ============

@api_router.get("/")
async def root():
    return {"message": "API Preparo Concurso Online"}

@api_router.post("/auth/register", response_model=Token)
async def register(user_data: UserCreate):
    existing_user = await db.users.find_one({"email": user_data.email})
    if existing_user:
        raise HTTPException(status_code=400, detail="Email já cadastrado")

    hashed_password = bcrypt.hashpw(user_data.password.encode('utf-8'), bcrypt.gensalt())

    # Check if this is the main admin
    is_main_admin = user_data.email.lower() == ADMIN_EMAIL.lower()

    user = User(email=user_data.email, name=user_data.name, is_admin=is_main_admin)
    user_dict = user.model_dump()
    user_dict['created_at'] = user_dict['created_at'].isoformat()
    user_dict['password'] = hashed_password.decode('utf-8')

    await db.users.insert_one(user_dict)
    access_token = create_access_token({"sub": user.id, "email": user.email})

    return Token(access_token=access_token, token_type="bearer", user=user)

@api_router.post("/auth/login", response_model=Token)
async def login(credentials: UserLogin):
    user = await db.users.find_one({"email": credentials.email}, {"_id": 0})
    if not user:
        raise HTTPException(status_code=401, detail="Email ou senha incorretos")

    if not bcrypt.checkpw(credentials.password.encode('utf-8'), user['password'].encode('utf-8')):
        raise HTTPException(status_code=401, detail="Email ou senha incorretos")

    if isinstance(user.get('created_at'), str):
        try:
            user['created_at'] = datetime.fromisoformat(user['created_at'])
        except Exception:
            pass

    user_obj = User(**{k: v for k, v in user.items() if k != 'password'})
    access_token = create_access_token({"sub": user_obj.id, "email": user_obj.email})

    return Token(access_token=access_token, token_type="bearer", user=user_obj)

@api_router.get("/auth/me", response_model=User)
async def get_me(token: str = Header(...)):
    user = await get_current_user(token)
    if not user:
        raise HTTPException(status_code=401, detail="Token inválido")
    return User(**user)

@api_router.put("/profile", response_model=User)
async def update_profile(update_data: UserUpdate, token: str = Header(...)):
    user = await get_current_user(token)
    if not user:
        raise HTTPException(status_code=401, detail="Token inválido")

    update_fields = {k: v for k, v in update_data.model_dump().items() if v is not None}

    if update_fields:
        await db.users.update_one({"id": user['id']}, {"$set": update_fields})
        user.update(update_fields)
        return User(**user)

    return User(**user)

@api_router.delete("/profile")
async def delete_own_account(token: str = Header(...)):
    user = await get_current_user(token)
    if not user:
        raise HTTPException(status_code=401, detail="Token inválido")

    # Delete user data
    await db.users.delete_one({"id": user['id']})
    await db.posts.delete_many({"user_id": user['id']})
    await db.comments.delete_many({"user_id": user['id']})
    await db.study_plans.delete_many({"user_id": user['id']})
    await db.lesson_progress.delete_many({"user_id": user['id']})

    return {"success": True, "message": "Conta deletada"}

# ============ ADMIN ROUTES ============

@api_router.post("/admin/make-admin/{user_id}")
async def make_admin(user_id: str, token: str = Header(...)):
    current_user = await get_current_user(token)
    if not current_user or not is_admin(current_user):
        raise HTTPException(status_code=403, detail="Apenas admins")

    await db.users.update_one({"id": user_id}, {"$set": {"is_admin": True}})
    return {"success": True}

@api_router.delete("/admin/delete-user/{user_id}")
async def admin_delete_user(user_id: str, token: str = Header(...)):
    current_user = await get_current_user(token)
    if not current_user or not is_admin(current_user):
        raise HTTPException(status_code=403, detail="Apenas admins")

    # Delete user and all their data
    await db.users.delete_one({"id": user_id})
    await db.posts.delete_many({"user_id": user_id})
    await db.comments.delete_many({"user_id": user_id})
    await db.study_plans.delete_many({"user_id": user_id})
    await db.lesson_progress.delete_many({"user_id": user_id})

    return {"success": True}

@api_router.delete("/admin/delete-post/{post_id}")
async def admin_delete_post(post_id: str, token: str = Header(...)):
    current_user = await get_current_user(token)
    if not current_user:
        raise HTTPException(status_code=401, detail="Login necessário")

    post = await db.posts.find_one({"id": post_id})
    if not post:
        raise HTTPException(status_code=404, detail="Post não encontrado")

    # Check if user is admin or post owner
    if not (is_admin(current_user) or post['user_id'] == current_user['id']):
        raise HTTPException(status_code=403, detail="Sem permissão")

    await db.posts.delete_one({"id": post_id})
    await db.comments.delete_many({"post_id": post_id})

    return {"success": True}

@api_router.get("/admin/users", response_model=List[User])
async def get_all_users(token: str = Header(...)):
    current_user = await get_current_user(token)
    if not current_user or not is_admin(current_user):
        raise HTTPException(status_code=403, detail="Apenas admins")

    users = await db.users.find({}, {"_id": 0, "password": 0}).to_list(1000)

    for user in users:
        if isinstance(user.get('created_at'), str):
            try:
                user['created_at'] = datetime.fromisoformat(user['created_at'])
            except Exception:
                pass

    return users

# ============ STUDY PLAN ROUTES ============

@api_router.post("/ai/create-study-plan", response_model=StudyPlan)
async def create_study_plan(plan_data: StudyPlanCreate, token: Optional[str] = Header(None)):
    user = await get_current_user(token)

    chat = LlmChat(
        api_key=EMERGENT_LLM_KEY,
        session_id=f"plan-{uuid.uuid4()}",
        system_message="Você é especialista em criar cronogramas educacionais detalhados com aulas completas."
    ).with_model("gemini", "gemini-2.0-flash")

    # Calculate number of days until exam
    from datetime import datetime as dt
    try:
        exam_date = dt.strptime(plan_data.exam_date, "%Y-%m-%d")
        today = dt.now()
        days_until_exam = (exam_date - today).days
        if days_until_exam < 1:
            days_until_exam = 30
    except:
        days_until_exam = 30

    lessons_per_day = 4
    total_lessons = days_until_exam * lessons_per_day

    prompt = f"""Crie um cronograma de estudos COMPLETO E DETALHADO com aulas educacionais:

**Informações:**
- Assunto: {plan_data.subject}
- Banca: {plan_data.banca}
- Escolaridade: {plan_data.escolaridade}
- Finalidade: {plan_data.finalidade}
- Dias até exame: {days_until_exam}
- Horas por dia: {plan_data.daily_hours}h
- Nível: {plan_data.difficulty_level}
- Total de aulas: {total_lessons} ({lessons_per_day} aulas por dia)

**TAREFA:** Crie {min(total_lessons, 80)} aulas completas e educacionais. Cada aula DEVE ter:

1. **title**: Título claro e específico da aula (ex: "Introdução à Álgebra Linear")

2. **detailed_content**: Conteúdo EDUCACIONAL COMPLETO (mínimo 800 palavras) que ENSINE o tópico:
   - Explicação clara do conceito
   - Exemplos práticos detalhados
   - Analogias para facilitar entendimento
   - Dicas de memorização
   - Aplicações práticas
   - Fórmulas quando aplicável

3. **questions**: Exatamente 5 questões de múltipla escolha desafiadoras:
{{
  "question": "texto da questão clara e objetiva",
  "options": ["A) opção 1", "B) opção 2", "C) opção 3", "D) opção 4"],
  "correct_answer": "A"
}}

IMPORTANTE: O conteúdo deve ser DIDÁTICO e COMPLETO, como se fosse uma aula presencial.

Retorne APENAS JSON válido (sem markdown):
{{
  "lessons": [
    {{
      "day": 1,
      "title": "...",
      "detailed_content": "...",
      "questions": [...]
    }}
  ]
}}"""

    try:
        response = await chat.send_message(UserMessage(text=prompt))
        # assume response is a string
        response_text = response.strip() if isinstance(response, str) else str(response).strip()

        # strip possible code fences
        if response_text.startswith('```json'):
            response_text = response_text[7:]
        if response_text.startswith('```'):
            response_text = response_text[3:]
        if response_text.endswith('```'):
            response_text = response_text[:-3]
        response_text = response_text.strip()

        plan_content = json.loads(response_text)

        # Create lessons
        lessons = []
        for lesson_data in plan_content.get('lessons', []):
            lesson = Lesson(**lesson_data)
            lessons.append(lesson)

        study_plan = StudyPlan(
            user_id=user['id'] if user else None,
            subject=plan_data.subject,
            exam_date=plan_data.exam_date,
            daily_hours=plan_data.daily_hours,
            difficulty_level=plan_data.difficulty_level,
            banca=plan_data.banca,
            escolaridade=plan_data.escolaridade,
            finalidade=plan_data.finalidade,
            lessons=lessons
        )

        plan_dict = study_plan.model_dump()
        plan_dict['created_at'] = plan_dict['created_at'].isoformat()
        await db.study_plans.insert_one(plan_dict)

        return study_plan
    except Exception as e:
        logging.error(f"Erro: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Erro ao criar cronograma: {str(e)}")

@api_router.get("/study-plans", response_model=List[StudyPlan])
async def get_study_plans(token: Optional[str] = Header(None)):
    user = await get_current_user(token)

    if user:
        plans = await db.study_plans.find({"user_id": user['id']}, {"_id": 0}).sort("created_at", -1).to_list(100)
    else:
        plans = []

    for plan in plans:
        if isinstance(plan.get('created_at'), str):
            try:
                plan['created_at'] = datetime.fromisoformat(plan['created_at'])
            except Exception:
                pass

    return plans

@api_router.delete("/study-plans/{plan_id}")
async def delete_study_plan(plan_id: str, token: Optional[str] = Header(None)):
    user = await get_current_user(token)

    plan = await db.study_plans.find_one({"id": plan_id})
    if not plan:
        raise HTTPException(status_code=404, detail="Cronograma não encontrado")

    if user and plan.get('user_id') != user['id']:
        raise HTTPException(status_code=403, detail="Sem permissão")

    await db.study_plans.delete_one({"id": plan_id})
    await db.lesson_progress.delete_many({"plan_id": plan_id})
    return {"success": True}

@api_router.post("/lesson/submit")
async def submit_lesson(answer_data: LessonAnswer, plan_id: str, token: Optional[str] = Header(None)):
    user = await get_current_user(token)

    plan = await db.study_plans.find_one({"id": plan_id}, {"_id": 0})
    if not plan:
        raise HTTPException(status_code=404, detail="Plano não encontrado")

    # Find lesson
    lesson = None
    for l in plan.get('lessons', []):
        if l.get('id') == answer_data.lesson_id:
            lesson = l
            break

    if not lesson:
        raise HTTPException(status_code=404, detail="Aula não encontrada")

    # Check answers
    correct = sum(1 for i, answer in enumerate(answer_data.answers)
                  if i < len(lesson['questions']) and answer.get('answer') == lesson['questions'][i].get('correct_answer'))

    score = int((correct / len(lesson['questions'])) * 100) if lesson['questions'] else 0
    passed = score == 100  # Must get all correct

    # Get or create progress
    if user:
        progress = await db.lesson_progress.find_one({
            "user_id": user['id'],
            "plan_id": plan_id,
            "lesson_id": answer_data.lesson_id
        })

        if progress:
            attempts = progress.get('attempts', 0) + 1
            await db.lesson_progress.update_one(
                {"id": progress['id']},
                {"$set": {
                    "attempts": attempts,
                    "score": score,
                    "completed": passed,
                    "updated_at": datetime.now(timezone.utc).isoformat()
                }}
            )
        else:
            progress_obj = LessonProgress(
                user_id=user['id'],
                plan_id=plan_id,
                lesson_id=answer_data.lesson_id,
                completed=passed,
                attempts=1,
                score=score
            )
            progress_dict = progress_obj.model_dump()
            progress_dict['updated_at'] = progress_dict['updated_at'].isoformat()
            await db.lesson_progress.insert_one(progress_dict)
            attempts = 1
    else:
        attempts = 1

    return {
        "score": score,
        "correct": correct,
        "total": len(lesson['questions']),
        "passed": passed,
        "attempts": attempts,
        "show_answers": attempts >= 3 and not passed
    }

@api_router.get("/lesson-progress/{plan_id}")
async def get_lesson_progress(plan_id: str, token: Optional[str] = Header(None)):
    user = await get_current_user(token)

    if not user:
        return []

    progress_list = await db.lesson_progress.find({
        "user_id": user['id'],
        "plan_id": plan_id
    }, {"_id": 0}).to_list(1000)

    return progress_list

# ============ SOCIAL ROUTES ============

@api_router.post("/posts", response_model=Post)
async def create_post(post_data: PostCreate, token: str = Header(...)):
    user = await get_current_user(token)
    if not user:
        raise HTTPException(status_code=401, detail="Login necessário")

    if has_profanity(post_data.content):
        raise HTTPException(status_code=400, detail="Conteúdo contém palavras ofensivas")

    post = Post(
        user_id=user['id'],
        user_name=user['name'],
        user_avatar=user.get('avatar'),
        content=post_data.content,
        image=post_data.image
    )

    post_dict = post.model_dump()
    post_dict['created_at'] = post_dict['created_at'].isoformat()
    await db.posts.insert_one(post_dict)

    return post

@api_router.get("/posts", response_model=List[Post])
async def get_posts(token: Optional[str] = Header(None)):
    posts = await db.posts.find({}, {"_id": 0}).sort("created_at", -1).to_list(100)

    for post in posts:
        if isinstance(post.get('created_at'), str):
            try:
                post['created_at'] = datetime.fromisoformat(post['created_at'])
            except Exception:
                pass

    return posts

@api_router.post("/posts/{post_id}/like")
async def like_post(post_id: str, token: str = Header(...)):
    user = await get_current_user(token)
    if not user:
        raise HTTPException(status_code=401, detail="Login necessário")

    post = await db.posts.find_one({"id": post_id})
    if not post:
        raise HTTPException(status_code=404, detail="Post não encontrado")

    if user['id'] in post.get('likes', []):
        await db.posts.update_one({"id": post_id}, {"$pull": {"likes": user['id']}})
        return {"liked": False}
    else:
        await db.posts.update_one({"id": post_id}, {"$addToSet": {"likes": user['id']}})
        return {"liked": True}

@api_router.post("/posts/{post_id}/comments", response_model=Comment)
async def create_comment(post_id: str, comment_data: CommentCreate, token: str = Header(...)):
    user = await get_current_user(token)
    if not user:
        raise HTTPException(status_code=401, detail="Login necessário")

    if has_profanity(comment_data.content):
        raise HTTPException(status_code=400, detail="Comentário contém palavras ofensivas")

    comment = Comment(
        post_id=post_id,
        user_id=user['id'],
        user_name=user['name'],
        user_avatar=user.get('avatar'),
        content=comment_data.content
    )

    comment_dict = comment.model_dump()
    comment_dict['created_at'] = comment_dict['created_at'].isoformat()
    await db.comments.insert_one(comment_dict)

    await db.posts.update_one({"id": post_id}, {"$inc": {"comments_count": 1}})

    return comment

@api_router.get("/posts/{post_id}/comments", response_model=List[Comment])
async def get_comments(post_id: str):
    comments = await db.comments.find({"post_id": post_id}, {"_id": 0}).sort("created_at", -1).to_list(100)

    for comment in comments:
        if isinstance(comment.get('created_at'), str):
            try:
                comment['created_at'] = datetime.fromisoformat(comment['created_at'])
            except Exception:
                pass

    return comments

@api_router.post("/users/{user_id}/follow")
async def follow_user(user_id: str, token: str = Header(...)):
    current_user = await get_current_user(token)
    if not current_user:
        raise HTTPException(status_code=401, detail="Login necessário")

    if user_id == current_user['id']:
        raise HTTPException(status_code=400, detail="Não pode seguir a si mesmo")

    target_user = await db.users.find_one({"id": user_id})
    if not target_user:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")

    is_following = user_id in current_user.get('following', [])

    if is_following:
        await db.users.update_one({"id": current_user['id']}, {"$pull": {"following": user_id}})
        await db.users.update_one({"id": user_id}, {"$pull": {"followers": current_user['id']}})
        return {"following": False}
    else:
        await db.users.update_one({"id": current_user['id']}, {"$addToSet": {"following": user_id}})
        await db.users.update_one({"id": user_id}, {"$addToSet": {"followers": current_user['id']}})
        return {"following": True}

@api_router.get("/users/search")
async def search_users(q: str):
    users = await db.users.find(
        {"name": {"$regex": q, "$options": "i"}},
        {"_id": 0, "password": 0}
    ).limit(20).to_list(20)

    return users

@api_router.post("/groups", response_model=Group)
async def create_group(group_data: GroupCreate, token: str = Header(...)):
    user = await get_current_user(token)
    if not user:
        raise HTTPException(status_code=401, detail="Login necessário")

    group = Group(
        name=group_data.name,
        description=group_data.description,
        concurso=group_data.concurso,
        created_by=user['id'],
        members=[user['id']]
    )

    group_dict = group.model_dump()
    group_dict['created_at'] = group_dict['created_at'].isoformat()
    await db.groups.insert_one(group_dict)

    return group

@api_router.get("/groups", response_model=List[Group])
async def get_groups():
    groups = await db.groups.find({}, {"_id": 0}).sort("created_at", -1).to_list(100)

    for group in groups:
        if isinstance(group.get('created_at'), str):
            try:
                group['created_at'] = datetime.fromisoformat(group['created_at'])
            except Exception:
                pass

    return groups

@api_router.post("/groups/{group_id}/join")
async def join_group(group_id: str, token: str = Header(...)):
    user = await get_current_user(token)
    if not user:
        raise HTTPException(status_code=401, detail="Login necessário")

    group = await db.groups.find_one({"id": group_id})
    if not group:
        raise HTTPException(status_code=404, detail="Grupo não encontrado")

    if user['id'] in group.get('members', []):
        await db.groups.update_one({"id": group_id}, {"$pull": {"members": user['id']}})
        return {"joined": False}
    else:
        await db.groups.update_one({"id": group_id}, {"$addToSet": {"members": user['id']}})
        return {"joined": True}

@api_router.get("/search")
async def search(q: str, type: str = "all"):
    results = {"posts": [], "users": [], "groups": []}

    if type in ["all", "posts"]:
        posts = await db.posts.find(
            {"content": {"$regex": q, "$options": "i"}},
            {"_id": 0}
        ).limit(20).to_list(20)
        results["posts"] = posts

    if type in ["all", "users"]:
        users = await db.users.find(
            {"name": {"$regex": q, "$options": "i"}},
            {"_id": 0, "password": 0}
        ).limit(20).to_list(20)
        results["users"] = users

    if type in ["all", "groups"]:
        groups = await db.groups.find(
            {"$or": [
                {"name": {"$regex": q, "$options": "i"}},
                {"concurso": {"$regex": q, "$options": "i"}}
            ]},
            {"_id": 0}
        ).limit(20).to_list(20)
        results["groups"] = groups

    return results

# ============ CONFIG ============

@api_router.get("/config")
async def get_config():
    config = await db.config.find_one({"type": "app"}, {"_id": 0})
    if not config:
        return {"pix_key": None, "pix_qr_code": None}
    return config

@api_router.put("/config")
async def update_config(config_data: AppConfig, admin_token: str = Header(...)):
    await db.config.update_one(
        {"type": "app"},
        {"$set": config_data.model_dump()},
        upsert=True
    )
    return {"success": True}

app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
