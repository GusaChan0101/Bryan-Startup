import requests
import sys
import json
from datetime import datetime, timedelta

class SaaSAPITester:
    def __init__(self, base_url="https://preparo-concurso-1.preview.emergentagent.com/api"):
        self.base_url = base_url
        self.token = None
        self.user_id = None
        self.tests_run = 0
        self.tests_passed = 0
        self.test_results = []

    def log_test(self, name, success, details=""):
        """Log test result"""
        self.tests_run += 1
        if success:
            self.tests_passed += 1
            print(f"✅ {name} - PASSED")
        else:
            print(f"❌ {name} - FAILED: {details}")
        
        self.test_results.append({
            "test": name,
            "success": success,
            "details": details
        })

    def run_test(self, name, method, endpoint, expected_status, data=None, params=None):
        """Run a single API test"""
        url = f"{self.base_url}/{endpoint}"
        headers = {'Content-Type': 'application/json'}
        
        # Add token to params if available
        if self.token and params is None:
            params = {"token": self.token}
        elif self.token and params:
            params["token"] = self.token

        print(f"\n🔍 Testing {name}...")
        print(f"   URL: {url}")
        if params:
            print(f"   Params: {params}")
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=headers, params=params, timeout=30)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=headers, params=params, timeout=30)

            print(f"   Status: {response.status_code}")
            
            success = response.status_code == expected_status
            details = ""
            
            if not success:
                details = f"Expected {expected_status}, got {response.status_code}"
                try:
                    error_detail = response.json()
                    details += f" - {error_detail}"
                except:
                    details += f" - {response.text[:200]}"
            
            self.log_test(name, success, details)
            
            if success:
                try:
                    return True, response.json()
                except:
                    return True, response.text
            else:
                return False, details

        except Exception as e:
            error_msg = f"Request failed: {str(e)}"
            self.log_test(name, False, error_msg)
            return False, error_msg

    def test_root_endpoint(self):
        """Test root API endpoint"""
        success, response = self.run_test(
            "Root API Endpoint",
            "GET",
            "",
            200
        )
        return success

    def test_register(self):
        """Test user registration"""
        test_email = f"test_{datetime.now().strftime('%Y%m%d_%H%M%S')}@test.com"
        success, response = self.run_test(
            "User Registration",
            "POST",
            "auth/register",
            200,
            data={
                "email": test_email,
                "password": "TestPass123!",
                "name": "Test User"
            }
        )
        
        if success and isinstance(response, dict):
            self.token = response.get('access_token')
            if response.get('user'):
                self.user_id = response['user'].get('id')
            print(f"   Token obtained: {self.token[:20]}..." if self.token else "   No token received")
            
        return success

    def test_login(self):
        """Test user login with existing user"""
        # First register a user
        test_email = f"login_test_{datetime.now().strftime('%Y%m%d_%H%M%S')}@test.com"
        register_success, _ = self.run_test(
            "Register for Login Test",
            "POST",
            "auth/register",
            200,
            data={
                "email": test_email,
                "password": "TestPass123!",
                "name": "Login Test User"
            }
        )
        
        if not register_success:
            return False
            
        # Now test login
        success, response = self.run_test(
            "User Login",
            "POST",
            "auth/login",
            200,
            data={
                "email": test_email,
                "password": "TestPass123!"
            }
        )
        
        return success

    def test_get_me(self):
        """Test get current user endpoint"""
        if not self.token:
            self.log_test("Get Current User", False, "No token available")
            return False
            
        success, response = self.run_test(
            "Get Current User",
            "GET",
            "auth/me",
            200
        )
        return success

    def test_generate_quiz(self):
        """Test AI quiz generation"""
        if not self.token:
            self.log_test("Generate Quiz", False, "No token available")
            return False
            
        success, response = self.run_test(
            "Generate AI Quiz",
            "POST",
            "ai/generate-quiz",
            200,
            data={
                "subject": "Direito Constitucional",
                "difficulty": "medio",
                "num_questions": 3
            }
        )
        
        if success and isinstance(response, dict):
            self.quiz_id = response.get('id')
            print(f"   Quiz ID: {self.quiz_id}")
            
        return success

    def test_submit_quiz(self):
        """Test quiz submission"""
        if not self.token:
            self.log_test("Submit Quiz", False, "No token available")
            return False
            
        if not hasattr(self, 'quiz_id') or not self.quiz_id:
            self.log_test("Submit Quiz", False, "No quiz ID available")
            return False
            
        # Submit dummy answers
        success, response = self.run_test(
            "Submit Quiz",
            "POST",
            "ai/submit-quiz",
            200,
            data={
                "quiz_id": self.quiz_id,
                "answers": [
                    {"answer": "A"},
                    {"answer": "B"},
                    {"answer": "C"}
                ]
            }
        )
        return success

    def test_get_quizzes(self):
        """Test get user quizzes"""
        if not self.token:
            self.log_test("Get Quizzes", False, "No token available")
            return False
            
        success, response = self.run_test(
            "Get User Quizzes",
            "GET",
            "quizzes",
            200
        )
        return success

    def test_create_study_plan(self):
        """Test study plan creation"""
        if not self.token:
            self.log_test("Create Study Plan", False, "No token available")
            return False
            
        # Calculate exam date (30 days from now)
        exam_date = (datetime.now() + timedelta(days=30)).strftime('%Y-%m-%d')
        
        success, response = self.run_test(
            "Create Study Plan",
            "POST",
            "ai/create-study-plan",
            200,
            data={
                "subject": "Concurso TRF",
                "exam_date": exam_date,
                "daily_hours": 4,
                "difficulty_level": "intermediario"
            }
        )
        
        if success and isinstance(response, dict):
            self.plan_id = response.get('id')
            print(f"   Plan ID: {self.plan_id}")
            
        return success

    def test_get_study_plans(self):
        """Test get user study plans"""
        if not self.token:
            self.log_test("Get Study Plans", False, "No token available")
            return False
            
        success, response = self.run_test(
            "Get User Study Plans",
            "GET",
            "study-plans",
            200
        )
        return success

    def test_export_study_plan(self):
        """Test study plan export"""
        if not self.token:
            self.log_test("Export Study Plan", False, "No token available")
            return False
            
        if not hasattr(self, 'plan_id') or not self.plan_id:
            self.log_test("Export Study Plan", False, "No plan ID available")
            return False
            
        success, response = self.run_test(
            "Export Study Plan",
            "GET",
            f"study-plan/{self.plan_id}/export",
            200
        )
        return success

    def run_all_tests(self):
        """Run all API tests"""
        print("🚀 Starting SaaS API Testing...")
        print(f"Base URL: {self.base_url}")
        print("=" * 60)

        # Test sequence
        tests = [
            ("Root Endpoint", self.test_root_endpoint),
            ("User Registration", self.test_register),
            ("User Login", self.test_login),
            ("Get Current User", self.test_get_me),
            ("Generate Quiz", self.test_generate_quiz),
            ("Submit Quiz", self.test_submit_quiz),
            ("Get Quizzes", self.test_get_quizzes),
            ("Create Study Plan", self.test_create_study_plan),
            ("Get Study Plans", self.test_get_study_plans),
            ("Export Study Plan", self.test_export_study_plan),
        ]

        for test_name, test_func in tests:
            try:
                test_func()
            except Exception as e:
                self.log_test(test_name, False, f"Exception: {str(e)}")

        # Print summary
        print("\n" + "=" * 60)
        print("📊 TEST SUMMARY")
        print("=" * 60)
        print(f"Total Tests: {self.tests_run}")
        print(f"Passed: {self.tests_passed}")
        print(f"Failed: {self.tests_run - self.tests_passed}")
        print(f"Success Rate: {(self.tests_passed/self.tests_run*100):.1f}%" if self.tests_run > 0 else "0%")

        # Return results
        return {
            "total": self.tests_run,
            "passed": self.tests_passed,
            "failed": self.tests_run - self.tests_passed,
            "success_rate": (self.tests_passed/self.tests_run*100) if self.tests_run > 0 else 0,
            "results": self.test_results
        }

def main():
    tester = SaaSAPITester()
    results = tester.run_all_tests()
    
    # Exit with appropriate code
    return 0 if results["failed"] == 0 else 1

if __name__ == "__main__":
    sys.exit(main())