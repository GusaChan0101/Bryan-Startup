import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Trash2, Shield, Search, User } from 'lucide-react';
import axios from 'axios';
import { API } from '@/App';
import { toast } from 'sonner';

const AdminPanel = ({ user }) => {
  const [users, setUsers] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [deleteUser, setDeleteUser] = useState(null);
  const [promoteUser, setPromoteUser] = useState(null);

  const token = localStorage.getItem('token');

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    try {
      const response = await axios.get(`${API}/admin/users?token=${token}`);
      setUsers(response.data);
    } catch (error) {
      toast.error('Erro ao carregar usuários');
    }
  };

  const handleDeleteUser = async () => {
    if (!deleteUser) return;
    try {
      await axios.delete(`${API}/admin/delete-user/${deleteUser.id}?token=${token}`);
      toast.success('Usuário deletado!');
      await loadUsers();
    } catch (error) {
      toast.error('Erro ao deletar');
    } finally {
      setDeleteUser(null);
    }
  };

  const handlePromoteUser = async () => {
    if (!promoteUser) return;
    try {
      await axios.post(`${API}/admin/make-admin/${promoteUser.id}?token=${token}`);
      toast.success('Usuário promovido a admin!');
      await loadUsers();
    } catch (error) {
      toast.error('Erro ao promover');
    } finally {
      setPromoteUser(null);
    }
  };

  const filteredUsers = users.filter(
    (u) =>
      u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="max-w-6xl mx-auto">
      <Card className="p-6 mb-6 bg-red-50 border border-red-200">
        <div className="flex items-center gap-3 mb-2">
          <Shield className="w-8 h-8 text-red-600" />
          <h2 className="text-3xl font-bold text-gray-900">Painel de Administração</h2>
        </div>
        <p className="text-gray-600">Gerencie usuários e permissões da plataforma</p>
      </Card>
    </div>
  );
};

export default AdminPanel;
