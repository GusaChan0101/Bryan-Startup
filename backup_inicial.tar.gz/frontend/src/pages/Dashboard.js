import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { LogOut, Plus, BookOpen, Calendar, Download, CheckCircle, XCircle, User as UserIcon, Users, Trash2, Home, LogIn } from 'lucide-react';
import axios from 'axios';
import { API } from '@/App';
import { toast } from 'sonner';
import Social from '@/pages/Social';
import Profile from '@/pages/Profile';
import Support from '@/pages/Support';

const Dashboard = ({ user, setUser }) => {
  const navigate = useNavigate();
  const [quizzes, setQuizzes] = useState([]);
  const [studyPlans, setStudyPlans] = useState([]);
  const [loading, setLoading] = useState(false);
  const [activeView, setActiveView] = useState('quizzes');
  const [showQuizDialog, setShowQuizDialog] = useState(false);
  const [showPlanDialog, setShowPlanDialog] = useState(false);
  const [currentQuiz, setCurrentQuiz] = useState(null);
  const [userAnswers, setUserAnswers] = useState({});
  const [quizResult, setQuizResult] = useState(null);
  const [deleteItem, setDeleteItem] = useState(null);

  const [quizForm, setQuizForm] = useState({
    subject: '',
    difficulty: 'medio',
    num_questions: 5
  });

  const [planForm, setPlanForm] = useState({
    subject: '',
    exam_date: '',
    daily_hours: 2,
    difficulty_level: 'intermediario',
    banca: '',
    escolaridade: '',
    finalidade: ''
  });

  const token = localStorage.getItem('token');

  useEffect(() => {
    loadQuizzes();
    loadStudyPlans();
  }, []);

  const loadQuizzes = async () => {
    try {
      const response = await axios.get(`${API}/quizzes${token ? `?token=${token}` : ''}`);
      setQuizzes(response.data);
    } catch (error) {
      console.error('Erro ao carregar quizzes:', error);
    }
  };

  const loadStudyPlans = async () => {
    try {
      const response = await axios.get(`${API}/study-plans${token ? `?token=${token}` : ''}`);
      setStudyPlans(response.data);
    } catch (error) {
      console.error('Erro ao carregar planos:', error);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setUser(null);
    toast.success('Logout realizado!');
  };

  const generateQuiz = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await axios.post(
        `${API}/ai/generate-quiz${token ? `?token=${token}` : ''}`,
        quizForm
      );
      toast.success('Questionário gerado!');
      setCurrentQuiz(response.data);
      setUserAnswers({});
      setQuizResult(null);
      setShowQuizDialog(false);
      await loadQuizzes();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Erro ao gerar');
    } finally {
      setLoading(false);
    }
  };

  const submitQuiz = async () => {
    if (Object.keys(userAnswers).length !== currentQuiz.questions.length) {
      toast.error('Responda todas as questões');
      return;
    }

    setLoading(true);

    try {
      const answers = currentQuiz.questions.map((_, index) => ({
        answer: userAnswers[index]
      }));

      const response = await axios.post(
        `${API}/ai/submit-quiz${token ? `?token=${token}` : ''}`,
        {
          quiz_id: currentQuiz.id,
          answers
        }
      );

      setQuizResult(response.data);
      toast.success(`Você acertou ${response.data.correct} de ${response.data.total}!`);
      await loadQuizzes();
    } catch (error) {
      toast.error('Erro ao enviar');
    } finally {
      setLoading(false);
    }
  };

  const createStudyPlan = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      await axios.post(
        `${API}/ai/create-study-plan${token ? `?token=${token}` : ''}`,
        planForm
      );
      toast.success('Cronograma criado!');
      setShowPlanDialog(false);
      await loadStudyPlans();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Erro ao criar');
    } finally {
      setLoading(false);
    }
  };

  const downloadPlan = async (planId) => {
    try {
      const response = await axios.get(
        `${API}/study-plan/${planId}/export${token ? `?token=${token}` : ''}`,
        { responseType: 'blob' }
      );

      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `cronograma_${planId}.csv`);
      document.body.appendChild(link);
      link.click();
      link.remove();

      toast.success('Cronograma baixado!');
    } catch (error) {
      toast.error('Erro ao baixar');
    }
  };

  const handleDelete = async () => {
    if (!deleteItem) return;

    try {
      const endpoint = deleteItem.type === 'quiz' 
        ? `/quizzes/${deleteItem.id}` 
        : `/study-plans/${deleteItem.id}`;
      
      await axios.delete(`${API}${endpoint}${token ? `?token=${token}` : ''}`);
      toast.success('Deletado com sucesso!');
      
      if (deleteItem.type === 'quiz') {
        await loadQuizzes();
      } else {
        await loadStudyPlans();
      }
    } catch (error) {
      toast.error('Erro ao deletar');
    } finally {
      setDeleteItem(null);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50" data-testid="dashboard">
      {/* Mobile-Friendly Header */}
      <div className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate('/')}
                data-testid="home-btn"
              >
                <Home className="w-5 h-5" />
              </Button>
              <div>
                <h1 className="text-lg font-bold text-gray-900">
                  {user ? `Olá, ${user.name}!` : 'Bem-vindo!'}
                </h1>
                <p className="text-xs text-gray-500">Pronto para estudar?</p>
              </div>
            </div>
            
            {user ? (
              <Button
                data-testid="logout-btn"
                variant="outline"
                size="sm"
                onClick={handleLogout}
                className="flex items-center gap-2"
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden sm:inline">Sair</span>
              </Button>
            ) : (
              <Button
                data-testid="login-prompt-btn"
                variant="outline"
                size="sm"
                onClick={() => navigate('/')}
                className="flex items-center gap-2"
              >
                <LogIn className="w-4 h-4" />
                <span className="hidden sm:inline">Fazer Login</span>
              </Button>
            )}
          </div>

          {/* Horizontal Navigation */}
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            <Button
              data-testid="nav-quizzes"
              variant={activeView === 'quizzes' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setActiveView('quizzes')}
              className="flex items-center gap-2 whitespace-nowrap"
            >
              <BookOpen className="w-4 h-4" />
              Questionários
            </Button>
            <Button
              data-testid="nav-plans"
              variant={activeView === 'plans' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setActiveView('plans')}
              className="flex items-center gap-2 whitespace-nowrap"
            >
              <Calendar className="w-4 h-4" />
              Cronogramas
            </Button>
            {user && (
              <>
                <Button
                  data-testid="nav-social"
                  variant={activeView === 'social' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setActiveView('social')}
                  className="flex items-center gap-2 whitespace-nowrap"
                >
                  <Users className="w-4 h-4" />
                  Social
                </Button>
                <Button
                  data-testid="nav-profile"
                  variant={activeView === 'profile' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setActiveView('profile')}
                  className="flex items-center gap-2 whitespace-nowrap"
                >
                  <UserIcon className="w-4 h-4" />
                  Perfil
                </Button>
                <Button
                  data-testid="nav-support"
                  variant={activeView === 'support' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setActiveView('support')}
                  className="flex items-center gap-2 whitespace-nowrap"
                >
                  ❤️ Apoiar
                </Button>
              </>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-4 md:p-6">
        {/* Quizzes View */}
        {activeView === 'quizzes' && (
          <div>
            <div className="mb-6 flex justify-between items-center">
              <h2 className="text-2xl md:text-3xl font-bold text-gray-900">Questionários</h2>
              <Dialog open={showQuizDialog} onOpenChange={setShowQuizDialog}>
                <DialogTrigger asChild>
                  <Button data-testid="create-quiz-btn" className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="w-4 h-4 md:mr-2" />
                    <span className="hidden md:inline">Novo</span>
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Criar Questionário</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={generateQuiz} className="space-y-4">
                    <div>
                      <Label htmlFor="subject">Assunto</Label>
                      <Input
                        id="subject"
                        data-testid="quiz-subject-input"
                        placeholder="Ex: Matemática, História..."
                        value={quizForm.subject}
                        onChange={(e) => setQuizForm({ ...quizForm, subject: e.target.value })}
                        required
                        className="mt-2"
                      />
                    </div>
                    <div>
                      <Label htmlFor="difficulty">Dificuldade</Label>
                      <Select
                        value={quizForm.difficulty}
                        onValueChange={(value) => setQuizForm({ ...quizForm, difficulty: value })}
                      >
                        <SelectTrigger data-testid="quiz-difficulty-select" className="mt-2">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="facil">Fácil</SelectItem>
                          <SelectItem value="medio">Médio</SelectItem>
                          <SelectItem value="dificil">Difícil</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="num_questions">Número de Questões</Label>
                      <Input
                        id="num_questions"
                        data-testid="quiz-num-questions-input"
                        type="number"
                        min="3"
                        max="10"
                        value={quizForm.num_questions}
                        onChange={(e) => setQuizForm({ ...quizForm, num_questions: parseInt(e.target.value) })}
                        className="mt-2"
                      />
                    </div>
                    <Button
                      data-testid="generate-quiz-btn"
                      type="submit"
                      className="w-full bg-blue-600 hover:bg-blue-700"
                      disabled={loading}
                    >
                      {loading ? 'Gerando...' : 'Gerar'}
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            {currentQuiz && !quizResult ? (
              <Card className="p-4 md:p-6 mb-6">
                <div className="mb-6">
                  <h3 className="text-xl md:text-2xl font-bold text-gray-900 mb-2">{currentQuiz.subject}</h3>
                  <p className="text-gray-600">{currentQuiz.difficulty} | {currentQuiz.questions.length} questões</p>
                </div>

                {currentQuiz.questions.map((question, index) => (
                  <div key={index} className="question-card mb-4" data-testid={`question-${index}`}>
                    <h4 className="font-semibold text-base md:text-lg mb-4 text-gray-900">
                      {index + 1}. {question.question}
                    </h4>
                    <div className="space-y-2">
                      {question.options.map((option, optIndex) => (
                        <button
                          key={optIndex}
                          data-testid={`option-${index}-${optIndex}`}
                          className={`option-button text-left ${userAnswers[index] === option[0] ? 'selected' : ''}`}
                          onClick={() => setUserAnswers({ ...userAnswers, [index]: option[0] })}
                        >
                          {option}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}

                <Button
                  data-testid="submit-quiz-btn"
                  onClick={submitQuiz}
                  className="w-full bg-blue-600 hover:bg-blue-700 py-6"
                  disabled={loading}
                >
                  {loading ? 'Enviando...' : 'Enviar Respostas'}
                </Button>
              </Card>
            ) : quizResult ? (
              <Card className="p-6 mb-6 text-center">
                <div className="mb-6">
                  <div className="w-20 h-20 mx-auto mb-4 bg-blue-100 rounded-full flex items-center justify-center">
                    {quizResult.score >= 70 ? (
                      <CheckCircle className="w-10 h-10 text-green-600" />
                    ) : (
                      <XCircle className="w-10 h-10 text-orange-600" />
                    )}
                  </div>
                  <h3 className="text-3xl font-bold text-gray-900 mb-2">Resultado</h3>
                  <p className="text-xl text-gray-700 mb-4">
                    Você acertou {quizResult.correct} de {quizResult.total}
                  </p>
                  <p className="text-4xl font-bold text-blue-600">{quizResult.score}%</p>
                </div>

                <div className="space-y-4 text-left">
                  {currentQuiz.questions.map((question, index) => (
                    <div key={index} className="question-card">
                      <h4 className="font-semibold mb-2 text-gray-900">
                        {index + 1}. {question.question}
                      </h4>
                      <div className="space-y-2">
                        {question.options.map((option, optIndex) => {
                          const isCorrect = option[0] === question.correct_answer;
                          const isUserAnswer = userAnswers[index] === option[0];
                          return (
                            <div
                              key={optIndex}
                              className={`option-button ${
                                isCorrect ? 'correct' : isUserAnswer ? 'incorrect' : ''
                              }`}
                            >
                              {option}
                            </div>
                          );
                        })}
                      </div>
                      <div className="mt-3 p-3 bg-blue-50 rounded-lg">
                        <p className="text-sm text-gray-700">
                          <strong>Explicação:</strong> {question.explanation}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                <Button
                  data-testid="new-quiz-btn"
                  onClick={() => {
                    setCurrentQuiz(null);
                    setQuizResult(null);
                    setUserAnswers({});
                  }}
                  className="w-full bg-blue-600 hover:bg-blue-700 mt-6"
                >
                  Fazer Novo
                </Button>
              </Card>
            ) : null}

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
              {quizzes.map((quiz) => (
                <Card key={quiz.id} className="quiz-card p-4" data-testid={`quiz-card-${quiz.id}`}>
                  <div className="flex items-start justify-between mb-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      <BookOpen className="w-6 h-6 text-blue-600" />
                    </div>
                    <div className="flex items-center gap-2">
                      {quiz.score !== null && (
                        <div className="text-2xl font-bold text-blue-600">{quiz.score}%</div>
                      )}
                      <Button
                        data-testid={`delete-quiz-${quiz.id}`}
                        variant="ghost"
                        size="sm"
                        onClick={() => setDeleteItem({ type: 'quiz', id: quiz.id, name: quiz.subject })}
                      >
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </Button>
                    </div>
                  </div>
                  <h3 className="text-lg md:text-xl font-semibold mb-2 text-gray-900">{quiz.subject}</h3>
                  <p className="text-sm text-gray-600 mb-2">Dificuldade: {quiz.difficulty}</p>
                  <p className="text-sm text-gray-600 mb-3">{quiz.questions.length} questões</p>
                  {quiz.score === null && (
                    <Button
                      data-testid={`start-quiz-${quiz.id}`}
                      onClick={() => {
                        setCurrentQuiz(quiz);
                        setUserAnswers({});
                        setQuizResult(null);
                      }}
                      className="w-full bg-blue-600 hover:bg-blue-700"
                      size="sm"
                    >
                      Iniciar
                    </Button>
                  )}
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Plans View */}
        {activeView === 'plans' && (
          <div>
            <div className="mb-6 flex justify-between items-center">
              <h2 className="text-2xl md:text-3xl font-bold text-gray-900">Cronogramas</h2>
              <Dialog open={showPlanDialog} onOpenChange={setShowPlanDialog}>
                <DialogTrigger asChild>
                  <Button data-testid="create-plan-btn" className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="w-4 h-4 md:mr-2" />
                    <span className="hidden md:inline">Novo</span>
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Criar Cronograma</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={createStudyPlan} className="space-y-4">
                    <div>
                      <Label htmlFor="plan-subject">Assunto/Objetivo</Label>
                      <Input
                        id="plan-subject"
                        data-testid="plan-subject-input"
                        placeholder="Ex: Concurso TRF, ENEM..."
                        value={planForm.subject}
                        onChange={(e) => setPlanForm({ ...planForm, subject: e.target.value })}
                        required
                        className="mt-2"
                      />
                    </div>
                    <div>
                      <Label htmlFor="finalidade">Finalidade</Label>
                      <Input
                        id="finalidade"
                        data-testid="plan-finalidade-input"
                        placeholder="Para que é esse cronograma?"
                        value={planForm.finalidade}
                        onChange={(e) => setPlanForm({ ...planForm, finalidade: e.target.value })}
                        required
                        className="mt-2"
                      />
                    </div>
                    <div>
                      <Label htmlFor="banca">Banca (Opcional)</Label>
                      <Input
                        id="banca"
                        data-testid="plan-banca-input"
                        placeholder="Ex: CESPE, FCC..."
                        value={planForm.banca}
                        onChange={(e) => setPlanForm({ ...planForm, banca: e.target.value })}
                        className="mt-2"
                      />
                    </div>
                    <div>
                      <Label htmlFor="escolaridade">Escolaridade</Label>
                      <Select
                        value={planForm.escolaridade}
                        onValueChange={(value) => setPlanForm({ ...planForm, escolaridade: value })}
                      >
                        <SelectTrigger data-testid="plan-escolaridade-select" className="mt-2">
                          <SelectValue placeholder="Selecione..." />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="fundamental">Fundamental</SelectItem>
                          <SelectItem value="medio">Médio</SelectItem>
                          <SelectItem value="tecnico">Técnico</SelectItem>
                          <SelectItem value="superior">Superior</SelectItem>
                          <SelectItem value="pos">Pós-Graduação</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="exam-date">Data Alvo</Label>
                      <Input
                        id="exam-date"
                        data-testid="plan-exam-date-input"
                        type="date"
                        value={planForm.exam_date}
                        onChange={(e) => setPlanForm({ ...planForm, exam_date: e.target.value })}
                        required
                        className="mt-2"
                      />
                    </div>
                    <div>
                      <Label htmlFor="daily-hours">Horas por Dia</Label>
                      <Input
                        id="daily-hours"
                        data-testid="plan-daily-hours-input"
                        type="number"
                        min="1"
                        max="12"
                        value={planForm.daily_hours}
                        onChange={(e) => setPlanForm({ ...planForm, daily_hours: parseInt(e.target.value) })}
                        className="mt-2"
                      />
                    </div>
                    <div>
                      <Label htmlFor="difficulty-level">Nível</Label>
                      <Select
                        value={planForm.difficulty_level}
                        onValueChange={(value) => setPlanForm({ ...planForm, difficulty_level: value })}
                      >
                        <SelectTrigger data-testid="plan-difficulty-select" className="mt-2">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="iniciante">Iniciante</SelectItem>
                          <SelectItem value="intermediario">Intermediário</SelectItem>
                          <SelectItem value="avancado">Avançado</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <Button
                      data-testid="generate-plan-btn"
                      type="submit"
                      className="w-full bg-blue-600 hover:bg-blue-700"
                      disabled={loading}
                    >
                      {loading ? 'Criando...' : 'Criar'}
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            <div className="grid sm:grid-cols-2 gap-4 md:gap-6">
              {studyPlans.map((plan) => (
                <Card key={plan.id} className="plan-card p-4" data-testid={`plan-card-${plan.id}`}>
                  <div className="flex items-start justify-between mb-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      <Calendar className="w-6 h-6 text-blue-600" />
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        data-testid={`download-plan-${plan.id}`}
                        size="sm"
                        variant="outline"
                        onClick={() => downloadPlan(plan.id)}
                      >
                        <Download className="w-4 h-4" />
                      </Button>
                      <Button
                        data-testid={`delete-plan-${plan.id}`}
                        variant="ghost"
                        size="sm"
                        onClick={() => setDeleteItem({ type: 'plan', id: plan.id, name: plan.subject })}
                      >
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </Button>
                    </div>
                  </div>
                  <h3 className="text-lg md:text-xl font-semibold mb-2 text-gray-900">{plan.subject}</h3>
                  <p className="text-sm text-gray-600 mb-1">Finalidade: {plan.finalidade}</p>
                  {plan.banca && <p className="text-sm text-gray-600 mb-1">Banca: {plan.banca}</p>}
                  <p className="text-sm text-gray-600 mb-1">Data: {plan.exam_date}</p>
                  <p className="text-sm text-gray-600 mb-3">{plan.daily_hours}h/dia | {plan.difficulty_level}</p>
                  <div className="bg-gray-50 p-3 rounded-lg max-h-48 overflow-y-auto">
                    <pre className="text-xs text-gray-700 whitespace-pre-wrap">{plan.plan_content}</pre>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Social View */}
        {activeView === 'social' && user && <Social user={user} />}

        {/* Profile View */}
        {activeView === 'profile' && user && <Profile user={user} setUser={setUser} />}

        {/* Support View */}
        {activeView === 'support' && user && <Support />}
      </div>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteItem} onOpenChange={() => setDeleteItem(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja deletar "{deleteItem?.name}"? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="cancel-delete-btn">Cancelar</AlertDialogCancel>
            <AlertDialogAction
              data-testid="confirm-delete-btn"
              onClick={handleDelete}
              className="bg-red-600 hover:bg-red-700"
            >
              Deletar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default Dashboard;
