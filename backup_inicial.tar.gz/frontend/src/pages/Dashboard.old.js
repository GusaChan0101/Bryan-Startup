import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { LogOut, Plus, BookOpen, Calendar, Download, CheckCircle, XCircle, User as UserIcon, Users } from 'lucide-react';
import axios from 'axios';
import { API } from '@/App';
import { toast } from 'sonner';
import Social from '@/pages/Social';
import Profile from '@/pages/Profile';
import Support from '@/pages/Support';

const Dashboard = ({ user, setUser }) => {
  const [quizzes, setQuizzes] = useState([]);
  const [studyPlans, setStudyPlans] = useState([]);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('quizzes');
  const [showQuizDialog, setShowQuizDialog] = useState(false);
  const [showPlanDialog, setShowPlanDialog] = useState(false);
  const [currentQuiz, setCurrentQuiz] = useState(null);
  const [userAnswers, setUserAnswers] = useState({});
  const [quizResult, setQuizResult] = useState(null);

  const [quizForm, setQuizForm] = useState({
    subject: '',
    difficulty: 'medio',
    num_questions: 5
  });

  const [planForm, setPlanForm] = useState({
    subject: '',
    exam_date: '',
    daily_hours: 2,
    difficulty_level: 'intermediario',
    banca: '',
    escolaridade: '',
    finalidade: ''
  });

  const token = localStorage.getItem('token');

  useEffect(() => {
    loadQuizzes();
    loadStudyPlans();
  }, []);

  const loadQuizzes = async () => {
    try {
      const response = await axios.get(`${API}/quizzes?token=${token}`);
      setQuizzes(response.data);
    } catch (error) {
      console.error('Erro ao carregar quizzes:', error);
    }
  };

  const loadStudyPlans = async () => {
    try {
      const response = await axios.get(`${API}/study-plans?token=${token}`);
      setStudyPlans(response.data);
    } catch (error) {
      console.error('Erro ao carregar planos:', error);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setUser(null);
  };

  const generateQuiz = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await axios.post(
        `${API}/ai/generate-quiz?token=${token}`,
        quizForm
      );
      toast.success('Questionário gerado com sucesso!');
      setCurrentQuiz(response.data);
      setUserAnswers({});
      setQuizResult(null);
      setShowQuizDialog(false);
      await loadQuizzes();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Erro ao gerar questionário');
    } finally {
      setLoading(false);
    }
  };

  const submitQuiz = async () => {
    if (Object.keys(userAnswers).length !== currentQuiz.questions.length) {
      toast.error('Por favor, responda todas as questões');
      return;
    }

    setLoading(true);

    try {
      const answers = currentQuiz.questions.map((_, index) => ({
        answer: userAnswers[index]
      }));

      const response = await axios.post(
        `${API}/ai/submit-quiz?token=${token}`,
        {
          quiz_id: currentQuiz.id,
          answers
        }
      );

      setQuizResult(response.data);
      toast.success(`Você acertou ${response.data.correct} de ${response.data.total} questões!`);
      await loadQuizzes();
    } catch (error) {
      toast.error('Erro ao enviar respostas');
    } finally {
      setLoading(false);
    }
  };

  const createStudyPlan = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      await axios.post(
        `${API}/ai/create-study-plan?token=${token}`,
        planForm
      );
      toast.success('Cronograma criado com sucesso!');
      setShowPlanDialog(false);
      await loadStudyPlans();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Erro ao criar cronograma');
    } finally {
      setLoading(false);
    }
  };

  const downloadPlan = async (planId) => {
    try {
      const response = await axios.get(
        `${API}/study-plan/${planId}/export?token=${token}`,
        { responseType: 'blob' }
      );

      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `cronograma_${planId}.csv`);
      document.body.appendChild(link);
      link.click();
      link.remove();

      toast.success('Cronograma baixado com sucesso!');
    } catch (error) {
      toast.error('Erro ao baixar cronograma');
    }
  };

  return (
    <div className="dashboard-container" data-testid="dashboard">
      <div className="dashboard-header">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Olá, {user.name}!</h1>
            <p className="text-gray-600">Pronto para estudar hoje?</p>
          </div>
          <Button
            data-testid="logout-btn"
            variant="outline"
            onClick={handleLogout}
            className="flex items-center gap-2"
          >
            <LogOut className="w-4 h-4" />
            Sair
          </Button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full max-w-2xl grid-cols-5 mb-8">
            <TabsTrigger value="quizzes" data-testid="tab-quizzes">Questionários</TabsTrigger>
            <TabsTrigger value="plans" data-testid="tab-plans">Cronogramas</TabsTrigger>
            <TabsTrigger value="social" data-testid="tab-social">Social</TabsTrigger>
            <TabsTrigger value="profile" data-testid="tab-profile">Perfil</TabsTrigger>
            <TabsTrigger value="support" data-testid="tab-support">Apoiar</TabsTrigger>
          </TabsList>

          <TabsContent value="quizzes">
            <div className="mb-6 flex justify-between items-center">
              <h2 className="text-3xl font-bold text-gray-900">Meus Questionários</h2>
              <Dialog open={showQuizDialog} onOpenChange={setShowQuizDialog}>
                <DialogTrigger asChild>
                  <Button data-testid="create-quiz-btn" className="bg-blue-600 hover:bg-blue-700 flex items-center gap-2">
                    <Plus className="w-4 h-4" />
                    Novo Questionário
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Criar Novo Questionário</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={generateQuiz} className="space-y-4">
                    <div>
                      <Label htmlFor="subject">Matéria/Assunto</Label>
                      <Input
                        id="subject"
                        data-testid="quiz-subject-input"
                        placeholder="Ex: Direito Constitucional, Matemática..."
                        value={quizForm.subject}
                        onChange={(e) => setQuizForm({ ...quizForm, subject: e.target.value })}
                        required
                        className="mt-2"
                      />
                    </div>
                    <div>
                      <Label htmlFor="difficulty">Dificuldade</Label>
                      <Select
                        value={quizForm.difficulty}
                        onValueChange={(value) => setQuizForm({ ...quizForm, difficulty: value })}
                      >
                        <SelectTrigger data-testid="quiz-difficulty-select" className="mt-2">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="facil">Fácil</SelectItem>
                          <SelectItem value="medio">Médio</SelectItem>
                          <SelectItem value="dificil">Difícil</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="num_questions">Número de Questões</Label>
                      <Input
                        id="num_questions"
                        data-testid="quiz-num-questions-input"
                        type="number"
                        min="3"
                        max="10"
                        value={quizForm.num_questions}
                        onChange={(e) => setQuizForm({ ...quizForm, num_questions: parseInt(e.target.value) })}
                        className="mt-2"
                      />
                    </div>
                    <Button
                      data-testid="generate-quiz-btn"
                      type="submit"
                      className="w-full bg-blue-600 hover:bg-blue-700"
                      disabled={loading}
                    >
                      {loading ? 'Gerando...' : 'Gerar Questionário'}
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            {currentQuiz && !quizResult ? (
              <Card className="p-6 mb-6">
                <div className="mb-6">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">{currentQuiz.subject}</h3>
                  <p className="text-gray-600">Dificuldade: {currentQuiz.difficulty} | {currentQuiz.questions.length} questões</p>
                </div>

                {currentQuiz.questions.map((question, index) => (
                  <div key={index} className="question-card" data-testid={`question-${index}`}>
                    <h4 className="font-semibold text-lg mb-4 text-gray-900">
                      {index + 1}. {question.question}
                    </h4>
                    <div className="space-y-2">
                      {question.options.map((option, optIndex) => (
                        <button
                          key={optIndex}
                          data-testid={`option-${index}-${optIndex}`}
                          className={`option-button ${userAnswers[index] === option[0] ? 'selected' : ''}`}
                          onClick={() => setUserAnswers({ ...userAnswers, [index]: option[0] })}
                        >
                          {option}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}

                <Button
                  data-testid="submit-quiz-btn"
                  onClick={submitQuiz}
                  className="w-full bg-blue-600 hover:bg-blue-700 py-6 text-lg"
                  disabled={loading}
                >
                  {loading ? 'Enviando...' : 'Enviar Respostas'}
                </Button>
              </Card>
            ) : quizResult ? (
              <Card className="p-6 mb-6 text-center">
                <div className="mb-6">
                  <div className="w-20 h-20 mx-auto mb-4 bg-blue-100 rounded-full flex items-center justify-center">
                    {quizResult.score >= 70 ? (
                      <CheckCircle className="w-10 h-10 text-green-600" />
                    ) : (
                      <XCircle className="w-10 h-10 text-orange-600" />
                    )}
                  </div>
                  <h3 className="text-3xl font-bold text-gray-900 mb-2">Resultado</h3>
                  <p className="text-xl text-gray-700 mb-4">
                    Você acertou {quizResult.correct} de {quizResult.total} questões
                  </p>
                  <p className="text-4xl font-bold text-blue-600">{quizResult.score}%</p>
                </div>

                <div className="space-y-4">
                  {currentQuiz.questions.map((question, index) => (
                    <div key={index} className="question-card text-left">
                      <h4 className="font-semibold mb-2 text-gray-900">
                        {index + 1}. {question.question}
                      </h4>
                      <div className="space-y-2">
                        {question.options.map((option, optIndex) => {
                          const isCorrect = option[0] === question.correct_answer;
                          const isUserAnswer = userAnswers[index] === option[0];
                          return (
                            <div
                              key={optIndex}
                              className={`option-button ${
                                isCorrect ? 'correct' : isUserAnswer ? 'incorrect' : ''
                              }`}
                            >
                              {option}
                            </div>
                          );
                        })}
                      </div>
                      <div className="mt-3 p-3 bg-blue-50 rounded-lg">
                        <p className="text-sm text-gray-700">
                          <strong>Explicação:</strong> {question.explanation}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                <Button
                  data-testid="new-quiz-btn"
                  onClick={() => {
                    setCurrentQuiz(null);
                    setQuizResult(null);
                    setUserAnswers({});
                  }}
                  className="w-full bg-blue-600 hover:bg-blue-700 mt-6"
                >
                  Fazer Novo Questionário
                </Button>
              </Card>
            ) : null}

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {quizzes.map((quiz) => (
                <Card key={quiz.id} className="quiz-card" data-testid={`quiz-card-${quiz.id}`}>
                  <div className="flex items-start justify-between mb-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      <BookOpen className="w-6 h-6 text-blue-600" />
                    </div>
                    {quiz.score !== null && (
                      <div className="text-2xl font-bold text-blue-600">{quiz.score}%</div>
                    )}
                  </div>
                  <h3 className="text-xl font-semibold mb-2 text-gray-900">{quiz.subject}</h3>
                  <p className="text-gray-600 mb-2">Dificuldade: {quiz.difficulty}</p>
                  <p className="text-gray-600">{quiz.questions.length} questões</p>
                  {quiz.score === null && (
                    <Button
                      data-testid={`start-quiz-${quiz.id}`}
                      onClick={() => {
                        setCurrentQuiz(quiz);
                        setUserAnswers({});
                        setQuizResult(null);
                      }}
                      className="w-full mt-4 bg-blue-600 hover:bg-blue-700"
                    >
                      Iniciar Quiz
                    </Button>
                  )}
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="plans">
            <div className="mb-6 flex justify-between items-center">
              <h2 className="text-3xl font-bold text-gray-900">Meus Cronogramas</h2>
              <Dialog open={showPlanDialog} onOpenChange={setShowPlanDialog}>
                <DialogTrigger asChild>
                  <Button data-testid="create-plan-btn" className="bg-blue-600 hover:bg-blue-700 flex items-center gap-2">
                    <Plus className="w-4 h-4" />
                    Novo Cronograma
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Criar Cronograma de Estudo</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={createStudyPlan} className="space-y-4">
                    <div>
                      <Label htmlFor="plan-subject">Matéria/Concurso</Label>
                      <Input
                        id="plan-subject"
                        data-testid="plan-subject-input"
                        placeholder="Ex: Concurso TRF, ENEM..."
                        value={planForm.subject}
                        onChange={(e) => setPlanForm({ ...planForm, subject: e.target.value })}
                        required
                        className="mt-2"
                      />
                    </div>
                    <div>
                      <Label htmlFor="exam-date">Data da Prova</Label>
                      <Input
                        id="exam-date"
                        data-testid="plan-exam-date-input"
                        type="date"
                        value={planForm.exam_date}
                        onChange={(e) => setPlanForm({ ...planForm, exam_date: e.target.value })}
                        required
                        className="mt-2"
                      />
                    </div>
                    <div>
                      <Label htmlFor="daily-hours">Horas Disponíveis por Dia</Label>
                      <Input
                        id="daily-hours"
                        data-testid="plan-daily-hours-input"
                        type="number"
                        min="1"
                        max="12"
                        value={planForm.daily_hours}
                        onChange={(e) => setPlanForm({ ...planForm, daily_hours: parseInt(e.target.value) })}
                        className="mt-2"
                      />
                    </div>
                    <div>
                      <Label htmlFor="difficulty-level">Nível</Label>
                      <Select
                        value={planForm.difficulty_level}
                        onValueChange={(value) => setPlanForm({ ...planForm, difficulty_level: value })}
                      >
                        <SelectTrigger data-testid="plan-difficulty-select" className="mt-2">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="iniciante">Iniciante</SelectItem>
                          <SelectItem value="intermediario">Intermediário</SelectItem>
                          <SelectItem value="avancado">Avançado</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <Button
                      data-testid="generate-plan-btn"
                      type="submit"
                      className="w-full bg-blue-600 hover:bg-blue-700"
                      disabled={loading}
                    >
                      {loading ? 'Criando...' : 'Criar Cronograma'}
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              {studyPlans.map((plan) => (
                <Card key={plan.id} className="plan-card" data-testid={`plan-card-${plan.id}`}>
                  <div className="flex items-start justify-between mb-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      <Calendar className="w-6 h-6 text-blue-600" />
                    </div>
                    <Button
                      data-testid={`download-plan-${plan.id}`}
                      size="sm"
                      variant="outline"
                      onClick={() => downloadPlan(plan.id)}
                      className="flex items-center gap-2"
                    >
                      <Download className="w-4 h-4" />
                      Baixar CSV
                    </Button>
                  </div>
                  <h3 className="text-xl font-semibold mb-2 text-gray-900">{plan.subject}</h3>
                  <p className="text-gray-600 mb-2">Data da prova: {plan.exam_date}</p>
                  <p className="text-gray-600 mb-4">{plan.daily_hours}h por dia | {plan.difficulty_level}</p>
                  <div className="bg-gray-50 p-4 rounded-lg max-h-64 overflow-y-auto">
                    <pre className="text-sm text-gray-700 whitespace-pre-wrap">{plan.plan_content}</pre>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Social Tab */}
          <TabsContent value="social">
            <Social user={user} />
          </TabsContent>

          {/* Profile Tab */}
          <TabsContent value="profile">
            <Profile user={user} setUser={setUser} />
          </TabsContent>

          {/* Support Tab */}
          <TabsContent value="support">
            <Support />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Dashboard;