import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { BookOpen, Target, Calendar, Brain, LogIn } from 'lucide-react';
import axios from 'axios';
import { API } from '@/App';
import { toast } from 'sonner';

const Landing = ({ user, setUser }) => {
  const navigate = useNavigate();
  const [showAuth, setShowAuth] = useState(false);
  const [isLogin, setIsLogin] = useState(true);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: ''
  });

  const handleAuth = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const endpoint = isLogin ? '/auth/login' : '/auth/register';
      const response = await axios.post(`${API}${endpoint}`, formData);
      
      localStorage.setItem('token', response.data.access_token);
      setUser(response.data.user);
      toast.success(isLogin ? 'Login realizado!' : 'Conta criada!');
      setShowAuth(false);
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Erro ao processar');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="landing-container">
      {/* Header with Login Button */}
      <div className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 py-3 flex justify-between items-center">
          <h1 className="text-xl font-bold text-gray-900">Preparo Concurso</h1>
          {user ? (
            <div className="flex items-center gap-3">
              <span className="text-sm text-gray-700">Olá, {user.name}!</span>
              <Button
                data-testid="go-to-app-btn"
                onClick={() => navigate('/app')}
                className="bg-blue-600 hover:bg-blue-700"
              >
                Ir para o App
              </Button>
            </div>
          ) : (
            <Button
              data-testid="login-btn"
              variant="outline"
              onClick={() => setShowAuth(true)}
              className="flex items-center gap-2"
            >
              <LogIn className="w-4 h-4" />
              Entrar / Cadastrar
            </Button>
          )}
        </div>
      </div>

      <div className="hero-section pt-24">
        <div className="text-center mb-16">
          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-gray-900 mb-6">
            Prepare-se para o
            <span className="block text-blue-600">Sucesso no Concurso</span>
          </h1>
          <p className="text-lg sm:text-xl text-gray-700 max-w-2xl mx-auto mb-8">
            Plataforma inteligente com IA para gerar questionários personalizados e cronogramas de estudo otimizados
          </p>
          <Button
            data-testid="start-now-btn"
            size="lg"
            className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 text-lg rounded-full shadow-lg"
            onClick={() => navigate('/app')}
          >
            Começar Agora (Grátis)
          </Button>
          <p className="text-sm text-gray-500 mt-3">Nenhum cadastro necessário para experimentar</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mt-20">
          <div className="feature-card" data-testid="feature-ai">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
              <Brain className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="text-xl font-semibold mb-2 text-gray-900">IA Avançada</h3>
            <p className="text-gray-600">Questões geradas por inteligência artificial Gemini, adaptadas ao seu nível</p>
          </div>

          <div className="feature-card" data-testid="feature-quiz">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
              <BookOpen className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="text-xl font-semibold mb-2 text-gray-900">Questionários Personalizados</h3>
            <p className="text-gray-600">Crie quizzes sob medida para qualquer área de estudo</p>
          </div>

          <div className="feature-card" data-testid="feature-plan">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
              <Calendar className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="text-xl font-semibold mb-2 text-gray-900">Cronograma Inteligente</h3>
            <p className="text-gray-600">Plano de estudos personalizado exportável em Excel</p>
          </div>

          <div className="feature-card" data-testid="feature-progress">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
              <Target className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="text-xl font-semibold mb-2 text-gray-900">Rede Social</h3>
            <p className="text-gray-600">Conecte-se com outros estudantes e compartilhe progresso</p>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="mt-32 py-8 border-t border-gray-200 bg-white/50 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-gray-600 mb-2">
            Desenvolvido com dedicação por <strong className="text-gray-900">Bryan Menezes</strong> e <strong className="text-gray-900">Josué Oliveira</strong>
          </p>
          <p className="text-sm text-gray-500">
            © 2025 Preparo Concurso. Todos os direitos reservados.
          </p>
        </div>
      </footer>

      {/* Auth Dialog */}
      <Dialog open={showAuth} onOpenChange={setShowAuth}>
        <DialogContent className="auth-card">
          <DialogHeader>
            <DialogTitle className="text-center text-2xl">
              {isLogin ? 'Bem-vindo de volta' : 'Criar conta'}
            </DialogTitle>
          </DialogHeader>

          <form onSubmit={handleAuth} data-testid="auth-form">
            {!isLogin && (
              <div className="mb-4">
                <Label htmlFor="name">Nome Completo</Label>
                <Input
                  id="name"
                  data-testid="auth-name-input"
                  type="text"
                  placeholder="Seu nome"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required={!isLogin}
                  className="mt-2"
                />
              </div>
            )}

            <div className="mb-4">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                data-testid="auth-email-input"
                type="email"
                placeholder="seu@email.com"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                required
                className="mt-2"
              />
            </div>

            <div className="mb-6">
              <Label htmlFor="password">Senha</Label>
              <Input
                id="password"
                data-testid="auth-password-input"
                type="password"
                placeholder="••••••••"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                required
                className="mt-2"
              />
            </div>

            <Button
              data-testid="auth-submit-btn"
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white py-6 rounded-xl"
              disabled={loading}
            >
              {loading ? 'Processando...' : (isLogin ? 'Entrar' : 'Criar Conta')}
            </Button>
          </form>

          <div className="mt-4 text-center">
            <button
              data-testid="toggle-auth-mode-btn"
              onClick={() => setIsLogin(!isLogin)}
              className="text-blue-600 hover:text-blue-700 font-medium"
            >
              {isLogin ? 'Não tem conta? Cadastre-se' : 'Já tem conta? Faça login'}
            </button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Landing;