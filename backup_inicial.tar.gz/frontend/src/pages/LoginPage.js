import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { BookOpen } from 'lucide-react';
import axios from 'axios';
import { API } from '@/App';
import { toast } from 'sonner';

const LoginPage = ({ setUser }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: ''
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const endpoint = isLogin ? '/auth/login' : '/auth/register';
      const response = await axios.post(`${API}${endpoint}`, formData);
      
      localStorage.setItem('token', response.data.access_token);
      setUser(response.data.user);
      toast.success(isLogin ? 'Bem-vindo de volta!' : 'Conta criada com sucesso!');
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Erro ao processar');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{
      background: 'linear-gradient(to bottom, #3b5998, #8b9dc3)'
    }}>
      <div className="w-full max-w-5xl grid md:grid-cols-2 gap-8 items-center">
        {/* Left Side - Branding */}
        <div className="text-white space-y-6 hidden md:block">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-16 h-16 bg-white rounded-lg flex items-center justify-center shadow-lg">
              <BookOpen className="w-10 h-10 text-blue-600" />
            </div>
            <h1 className="text-5xl font-bold">Preparo Concurso</h1>
          </div>
          
          <h2 className="text-3xl font-semibold leading-tight">
            Plataforma de estudos com inteligência artificial
          </h2>
          
          <div className="space-y-3 text-lg">
            <div className="flex items-start gap-3">
              <span className="text-2xl">📚</span>
              <div>
                <p className="font-semibold">Cronogramas Personalizados</p>
                <p className="text-blue-100">Aulas completas geradas por IA</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <span className="text-2xl">✅</span>
              <div>
                <p className="font-semibold">Questionários Integrados</p>
                <p className="text-blue-100">Teste seus conhecimentos em cada aula</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <span className="text-2xl">👥</span>
              <div>
                <p className="font-semibold">Rede Social de Estudos</p>
                <p className="text-blue-100">Conecte-se com outros estudantes</p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side - Login/Register Form */}
        <Card className="bg-white rounded-xl shadow-2xl">
          <div className="p-8">
            {/* Mobile Logo */}
            <div className="md:hidden text-center mb-6">
              <div className="w-16 h-16 bg-blue-600 rounded-lg flex items-center justify-center shadow-lg mx-auto mb-3">
                <BookOpen className="w-10 h-10 text-white" />
              </div>
              <h1 className="text-3xl font-bold text-gray-900">Preparo Concurso</h1>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {!isLogin && (
                <Input
                  data-testid="register-name-input"
                  placeholder="Nome completo"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required={!isLogin}
                  className="h-12 text-base border-gray-300"
                />
              )}

              <Input
                data-testid="email-input"
                type="email"
                placeholder="Email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                required
                className="h-12 text-base border-gray-300"
              />

              <Input
                data-testid="password-input"
                type="password"
                placeholder="Senha"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                required
                className="h-12 text-base border-gray-300"
              />

              <Button
                data-testid="submit-btn"
                type="submit"
                disabled={loading}
                className="w-full h-12 text-base font-bold bg-blue-600 hover:bg-blue-700 text-white rounded-lg"
              >
                {loading ? 'Processando...' : (isLogin ? 'Entrar' : 'Cadastrar')}
              </Button>
            </form>

            <div className="mt-6 pt-6 border-t border-gray-200 text-center">
              <Button
                data-testid="toggle-mode-btn"
                type="button"
                onClick={() => setIsLogin(!isLogin)}
                variant="outline"
                className="w-full md:w-auto px-8 h-12 text-base font-semibold bg-green-500 hover:bg-green-600 text-white border-none"
              >
                {isLogin ? 'Criar nova conta' : 'Já tenho uma conta'}
              </Button>
            </div>
          </div>

          {/* Footer */}
          <div className="px-8 py-4 bg-gray-50 rounded-b-xl border-t border-gray-200">
            <p className="text-sm text-gray-600 text-center">
              Desenvolvido por <strong>Bryan Menezes</strong> e <strong>Josué Oliveira</strong>
            </p>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default LoginPage;
