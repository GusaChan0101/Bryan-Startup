import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { LogIn, LogOut, BookOpen, Users, UserIcon, Heart } from 'lucide-react';
import axios from 'axios';
import { API } from '@/App';
import { toast } from 'sonner';
import StudyPlanView from '@/pages/StudyPlanView';
import Social from '@/pages/Social';
import Profile from '@/pages/Profile';
import Support from '@/pages/Support';
import AdminPanel from '@/pages/AdminPanel';

const MainApp = ({ user, setUser }) => {
  const [showAuth, setShowAuth] = useState(false);
  const [isLogin, setIsLogin] = useState(true);
  const [loading, setLoading] = useState(false);
  const [activeView, setActiveView] = useState('plans');
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: ''
  });

  const handleAuth = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const endpoint = isLogin ? '/auth/login' : '/auth/register';
      const response = await axios.post(`${API}${endpoint}`, formData);
      
      localStorage.setItem('token', response.data.access_token);
      setUser(response.data.user);
      toast.success(isLogin ? 'Login realizado!' : 'Conta criada!');
      setShowAuth(false);
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Erro');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setUser(null);
    toast.success('Logout realizado!');
    setActiveView('plans');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h1 className="text-xl font-bold text-gray-900">
                {user ? `Olá, ${user.name}!` : 'Preparo Concurso'}
              </h1>
              <p className="text-xs text-gray-500">Plataforma de Estudos com IA</p>
            </div>
            
            {user ? (
              <Button
                data-testid="logout-btn"
                variant="outline"
                size="sm"
                onClick={handleLogout}
              >
                <LogOut className="w-4 h-4 mr-2" />
                Sair
              </Button>
            ) : (
              <Button
                data-testid="login-btn"
                onClick={() => setShowAuth(true)}
                className="bg-blue-600 hover:bg-blue-700"
                size="sm"
              >
                <LogIn className="w-4 h-4 mr-2" />
                Entrar
              </Button>
            )}
          </div>

          {/* Navigation */}
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            <Button
              data-testid="nav-plans"
              variant={activeView === 'plans' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setActiveView('plans')}
            >
              <BookOpen className="w-4 h-4 mr-2" />
              Cronogramas
            </Button>
            {user && (
              <>
                <Button
                  data-testid="nav-social"
                  variant={activeView === 'social' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setActiveView('social')}
                >
                  <Users className="w-4 h-4 mr-2" />
                  Social
                </Button>
                <Button
                  data-testid="nav-profile"
                  variant={activeView === 'profile' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setActiveView('profile')}
                >
                  <UserIcon className="w-4 h-4 mr-2" />
                  Perfil
                </Button>
                {user.is_admin && (
                  <Button
                    data-testid="nav-admin"
                    variant={activeView === 'admin' ? 'default' : 'ghost'}
                    size="sm"
                    onClick={() => setActiveView('admin')}
                    className="bg-red-600 hover:bg-red-700 text-white"
                  >
                    👑 Admin
                  </Button>
                )}
                <Button
                  data-testid="nav-support"
                  variant={activeView === 'support' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setActiveView('support')}
                >
                  <Heart className="w-4 h-4 mr-2" />
                  Apoiar
                </Button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto p-4">
        {activeView === 'plans' && <StudyPlanView user={user} />}
        {activeView === 'social' && user && <Social user={user} />}
        {activeView === 'profile' && user && <Profile user={user} setUser={setUser} />}
        {activeView === 'admin' && user?.is_admin && <AdminPanel user={user} />}
        {activeView === 'support' && user && <Support />}
      </div>

      {/* Footer */}
      <footer className="mt-16 py-8 border-t border-gray-200 bg-white/50 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-gray-600 mb-2">
            Desenvolvido com dedicação por <strong className="text-gray-900">Bryan Menezes</strong> e <strong className="text-gray-900">Josué Oliveira</strong>
          </p>
          <p className="text-sm text-gray-500">
            © 2025 Preparo Concurso. Todos os direitos reservados.
          </p>
        </div>
      </footer>

      {/* Auth Dialog */}
      <Dialog open={showAuth} onOpenChange={setShowAuth}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="text-center text-2xl">
              {isLogin ? 'Entrar' : 'Criar Conta'}
            </DialogTitle>
          </DialogHeader>

          <form onSubmit={handleAuth} className="space-y-4">
            {!isLogin && (
              <div>
                <Label htmlFor="name">Nome Completo</Label>
                <Input
                  id="name"
                  data-testid="auth-name-input"
                  placeholder="Seu nome"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required={!isLogin}
                  className="mt-2"
                />
              </div>
            )}

            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                data-testid="auth-email-input"
                type="email"
                placeholder="seu@email.com"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                required
                className="mt-2"
              />
            </div>

            <div>
              <Label htmlFor="password">Senha</Label>
              <Input
                id="password"
                data-testid="auth-password-input"
                type="password"
                placeholder="••••••••"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                required
                className="mt-2"
              />
            </div>

            <Button
              data-testid="auth-submit-btn"
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-700"
              disabled={loading}
            >
              {loading ? 'Processando...' : (isLogin ? 'Entrar' : 'Criar Conta')}
            </Button>

            <div className="text-center">
              <button
                type="button"
                data-testid="toggle-auth-mode-btn"
                onClick={() => setIsLogin(!isLogin)}
                className="text-blue-600 hover:text-blue-700 text-sm"
              >
                {isLogin ? 'Não tem conta? Cadastre-se' : 'Já tem conta? Faça login'}
              </button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default MainApp;
