import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { User, Camera } from 'lucide-react';
import axios from 'axios';
import { API } from '@/App';
import { toast } from 'sonner';

const Profile = ({ user, setUser }) => {
  const [editing, setEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: user?.name || '',
    avatar: user?.avatar || '',
    bio: user?.bio || ''
  });

  const token = localStorage.getItem('token');

  const handleUpdate = async () => {
    try {
      const response = await axios.put(
        `${API}/profile?token=${token}`,
        formData
      );
      setUser(response.data);
      setEditing(false);
      toast.success('Perfil atualizado!');
    } catch (error) {
      toast.error('Erro ao atualizar perfil');
    }
  };

  return (
    <div className="max-w-2xl mx-auto" data-testid="profile-container">
      <Card className="p-6">
        <div className="text-center mb-6">
          <div className="relative inline-block">
            <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              {user?.avatar ? (
                <img src={user.avatar} alt={user.name} className="w-24 h-24 rounded-full object-cover" />
              ) : (
                <User className="w-12 h-12 text-blue-600" />
              )}
            </div>
            {editing && (
              <button className="absolute bottom-4 right-0 w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white">
                <Camera className="w-4 h-4" />
              </button>
            )}
          </div>

          {!editing ? (
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">{user?.name}</h2>
              <p className="text-gray-600 mb-1">{user?.email}</p>
              {user?.bio && <p className="text-gray-700 mt-3">{user.bio}</p>}
              
              <div className="flex justify-center gap-6 mt-6 text-center">
                <div>
                  <p className="text-2xl font-bold text-blue-600">{user?.followers?.length || 0}</p>
                  <p className="text-sm text-gray-600">Seguidores</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-blue-600">{user?.following?.length || 0}</p>
                  <p className="text-sm text-gray-600">Seguindo</p>
                </div>
              </div>

              <Button
                data-testid="edit-profile-btn"
                onClick={() => setEditing(true)}
                className="mt-6 bg-blue-600 hover:bg-blue-700"
              >
                Editar Perfil
              </Button>
              
              <Button
                data-testid="delete-account-btn"
                onClick={async () => {
                  if (window.confirm('Tem certeza que deseja deletar sua conta? Esta ação não pode ser desfeita!')) {
                    if (window.confirm('ÚLTIMA CONFIRMAÇÃO: Todos seus dados serão perdidos permanentemente!')) {
                      try {
                        await axios.delete(`${API}/profile?token=${token}`);
                        localStorage.removeItem('token');
                        setUser(null);
                        toast.success('Conta deletada');
                        window.location.href = '/';
                      } catch (error) {
                        toast.error('Erro ao deletar conta');
                      }
                    }
                  }
                }}
                variant="outline"
                className="mt-3 border-red-600 text-red-600 hover:bg-red-50"
              >
                Deletar Minha Conta
              </Button>
            </div>
          ) : (
            <div className="space-y-4 text-left">
              <div>
                <Label htmlFor="name">Nome</Label>
                <Input
                  id="name"
                  data-testid="profile-name-input"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="mt-2"
                />
              </div>

              <div>
                <Label htmlFor="avatar">URL da Foto (opcional)</Label>
                <Input
                  id="avatar"
                  data-testid="profile-avatar-input"
                  placeholder="https://exemplo.com/foto.jpg"
                  value={formData.avatar}
                  onChange={(e) => setFormData({ ...formData, avatar: e.target.value })}
                  className="mt-2"
                />
              </div>

              <div>
                <Label htmlFor="bio">Bio</Label>
                <Textarea
                  id="bio"
                  data-testid="profile-bio-input"
                  placeholder="Conte um pouco sobre você..."
                  value={formData.bio}
                  onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                  rows={3}
                  className="mt-2"
                />
              </div>

              <div className="flex gap-2">
                <Button
                  data-testid="save-profile-btn"
                  onClick={handleUpdate}
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                >
                  Salvar
                </Button>
                <Button
                  data-testid="cancel-edit-btn"
                  onClick={() => setEditing(false)}
                  variant="outline"
                  className="flex-1"
                >
                  Cancelar
                </Button>
              </div>
            </div>
          )}
        </div>
      </Card>
    </div>
  );
};

export default Profile;