import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Heart, MessageCircle, Search, Plus, Users } from 'lucide-react';
import axios from 'axios';
import { API } from '@/App';
import { toast } from 'sonner';

const Social = ({ user }) => {
  const [posts, setPosts] = useState([]);
  const [groups, setGroups] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState({ posts: [], users: [], groups: [] });
  const [showPostDialog, setShowPostDialog] = useState(false);
  const [showGroupDialog, setShowGroupDialog] = useState(false);
  const [selectedPost, setSelectedPost] = useState(null);
  const [comments, setComments] = useState([]);
  const [newPost, setNewPost] = useState('');
  const [newComment, setNewComment] = useState('');
  const [newGroup, setNewGroup] = useState({ name: '', description: '', concurso: '' });
  const [activeTab, setActiveTab] = useState('feed');

  const token = localStorage.getItem('token');

  useEffect(() => {
    loadPosts();
    loadGroups();
  }, []);

  const loadPosts = async () => {
    try {
      const response = await axios.get(`${API}/posts`);
      setPosts(response.data);
    } catch (error) {
      console.error('Erro ao carregar posts:', error);
    }
  };

  const loadGroups = async () => {
    try {
      const response = await axios.get(`${API}/groups`);
      setGroups(response.data);
    } catch (error) {
      console.error('Erro ao carregar grupos:', error);
    }
  };

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;

    try {
      const response = await axios.get(`${API}/search?q=${encodeURIComponent(searchQuery)}`);
      setSearchResults(response.data);
      setActiveTab('search');
    } catch (error) {
      toast.error('Erro ao buscar');
    }
  };

  const createPost = async () => {
    if (!newPost.trim()) {
      toast.error('Escreva algo para postar');
      return;
    }

    try {
      await axios.post(`${API}/posts?token=${token}`, { content: newPost });
      toast.success('Post criado!');
      setNewPost('');
      setShowPostDialog(false);
      loadPosts();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Erro ao criar post');
    }
  };

  const likePost = async (postId) => {
    try {
      await axios.post(`${API}/posts/${postId}/like?token=${token}`);
      loadPosts();
    } catch (error) {
      toast.error('Erro ao curtir');
    }
  };

  const viewComments = async (post) => {
    setSelectedPost(post);
    try {
      const response = await axios.get(`${API}/posts/${post.id}/comments`);
      setComments(response.data);
    } catch (error) {
      toast.error('Erro ao carregar comentários');
    }
  };

  const addComment = async () => {
    if (!newComment.trim()) return;

    try {
      await axios.post(
        `${API}/posts/${selectedPost.id}/comments?token=${token}`,
        { content: newComment }
      );
      setNewComment('');
      toast.success('Comentário adicionado!');
      viewComments(selectedPost);
      loadPosts();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Erro ao comentar');
    }
  };

  const createGroup = async () => {
    if (!newGroup.name || !newGroup.concurso) {
      toast.error('Preencha nome e concurso');
      return;
    }

    try {
      await axios.post(`${API}/groups?token=${token}`, newGroup);
      toast.success('Grupo criado!');
      setNewGroup({ name: '', description: '', concurso: '' });
      setShowGroupDialog(false);
      loadGroups();
    } catch (error) {
      toast.error('Erro ao criar grupo');
    }
  };

  const joinGroup = async (groupId) => {
    try {
      await axios.post(`${API}/groups/${groupId}/join?token=${token}`);
      loadGroups();
      toast.success('Grupo atualizado!');
    } catch (error) {
      toast.error('Erro');
    }
  };

  return (
    <div className="max-w-4xl mx-auto" data-testid="social-container">
      {/* Search Bar */}
      <div className="mb-6 flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
          <Input
            data-testid="search-input"
            placeholder="Buscar posts, usuários ou grupos..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            className="pl-10"
          />
        </div>
        <Button data-testid="search-btn" onClick={handleSearch}>
          Buscar
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="feed" data-testid="tab-feed">Feed</TabsTrigger>
          <TabsTrigger value="groups" data-testid="tab-groups">Grupos</TabsTrigger>
          <TabsTrigger value="search" data-testid="tab-search">Busca</TabsTrigger>
        </TabsList>

        {/* Feed Tab */}
        <TabsContent value="feed">
          <div className="mb-4">
            <Dialog open={showPostDialog} onOpenChange={setShowPostDialog}>
              <DialogTrigger asChild>
                <Button data-testid="create-post-btn" className="w-full bg-blue-600 hover:bg-blue-700">
                  <Plus className="w-4 h-4 mr-2" />
                  Compartilhar seu progresso
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Criar Post</DialogTitle>
                </DialogHeader>
                <Textarea
                  data-testid="post-content-input"
                  placeholder="Compartilhe sua jornada de estudos..."
                  value={newPost}
                  onChange={(e) => setNewPost(e.target.value)}
                  rows={4}
                />
                <Button data-testid="submit-post-btn" onClick={createPost} className="bg-blue-600 hover:bg-blue-700">
                  Publicar
                </Button>
              </DialogContent>
            </Dialog>
          </div>

          <div className="space-y-4">
            {posts.map((post) => (
              <Card key={post.id} className="p-4" data-testid={`post-${post.id}`}>
                <div className="flex items-start gap-3 mb-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                    <span className="text-blue-600 font-semibold">{post.user_name[0].toUpperCase()}</span>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-semibold text-gray-900">{post.user_name}</h4>
                        <p className="text-sm text-gray-500">{new Date(post.created_at).toLocaleDateString('pt-BR')}</p>
                      </div>
                      {(user?.is_admin || post.user_id === user?.id) && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={async () => {
                            if (window.confirm('Deletar este post?')) {
                              try {
                                await axios.delete(`${API}/admin/delete-post/${post.id}?token=${token}`);
                                toast.success('Post deletado!');
                                loadPosts();
                              } catch (error) {
                                toast.error('Erro ao deletar');
                              }
                            }
                          }}
                        >
                          <span className="text-red-500">🗑️</span>
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
                <p className="text-gray-700 mb-3">{post.content}</p>
                <div className="flex gap-4">
                  <Button
                    data-testid={`like-post-${post.id}`}
                    variant="ghost"
                    size="sm"
                    onClick={() => likePost(post.id)}
                    className="flex items-center gap-2"
                  >
                    <Heart className={`w-4 h-4 ${post.likes?.includes(user?.id) ? 'fill-red-500 text-red-500' : ''}`} />
                    {post.likes?.length || 0}
                  </Button>
                  <Button
                    data-testid={`comment-post-${post.id}`}
                    variant="ghost"
                    size="sm"
                    onClick={() => viewComments(post)}
                    className="flex items-center gap-2"
                  >
                    <MessageCircle className="w-4 h-4" />
                    {post.comments_count || 0}
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Groups Tab */}
        <TabsContent value="groups">
          <div className="mb-4">
            <Dialog open={showGroupDialog} onOpenChange={setShowGroupDialog}>
              <DialogTrigger asChild>
                <Button data-testid="create-group-btn" className="w-full bg-blue-600 hover:bg-blue-700">
                  <Plus className="w-4 h-4 mr-2" />
                  Criar Grupo de Estudo
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Criar Grupo</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <Input
                    data-testid="group-name-input"
                    placeholder="Nome do grupo"
                    value={newGroup.name}
                    onChange={(e) => setNewGroup({ ...newGroup, name: e.target.value })}
                  />
                  <Input
                    data-testid="group-concurso-input"
                    placeholder="Concurso (ex: ENEM, TRF, etc)"
                    value={newGroup.concurso}
                    onChange={(e) => setNewGroup({ ...newGroup, concurso: e.target.value })}
                  />
                  <Textarea
                    data-testid="group-description-input"
                    placeholder="Descrição"
                    value={newGroup.description}
                    onChange={(e) => setNewGroup({ ...newGroup, description: e.target.value })}
                  />
                  <Button data-testid="submit-group-btn" onClick={createGroup} className="w-full bg-blue-600 hover:bg-blue-700">
                    Criar
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            {groups.map((group) => (
              <Card key={group.id} className="p-4" data-testid={`group-${group.id}`}>
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="font-semibold text-lg text-gray-900">{group.name}</h3>
                    <p className="text-sm text-blue-600">{group.concurso}</p>
                  </div>
                  <div className="flex items-center gap-1 text-gray-500">
                    <Users className="w-4 h-4" />
                    <span className="text-sm">{group.members?.length || 0}</span>
                  </div>
                </div>
                <p className="text-gray-600 text-sm mb-3">{group.description}</p>
                <Button
                  data-testid={`join-group-${group.id}`}
                  onClick={() => joinGroup(group.id)}
                  variant={group.members?.includes(user?.id) ? 'outline' : 'default'}
                  className="w-full"
                >
                  {group.members?.includes(user?.id) ? 'Sair' : 'Participar'}
                </Button>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Search Results Tab */}
        <TabsContent value="search">
          <div className="space-y-6">
            {searchResults.posts?.length > 0 && (
              <div>
                <h3 className="font-semibold text-lg mb-3">Posts</h3>
                <div className="space-y-3">
                  {searchResults.posts.map((post) => (
                    <Card key={post.id} className="p-3">
                      <p className="font-semibold">{post.user_name}</p>
                      <p className="text-sm text-gray-600">{post.content}</p>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {searchResults.users?.length > 0 && (
              <div>
                <h3 className="font-semibold text-lg mb-3">Usuários</h3>
                <div className="space-y-2">
                  {searchResults.users.map((user) => (
                    <Card key={user.id} className="p-3 flex items-center gap-3">
                      <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                        <span className="text-blue-600 font-semibold">{user.name[0].toUpperCase()}</span>
                      </div>
                      <div>
                        <p className="font-semibold">{user.name}</p>
                        <p className="text-sm text-gray-500">{user.email}</p>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {searchResults.groups?.length > 0 && (
              <div>
                <h3 className="font-semibold text-lg mb-3">Grupos</h3>
                <div className="space-y-2">
                  {searchResults.groups.map((group) => (
                    <Card key={group.id} className="p-3">
                      <p className="font-semibold">{group.name}</p>
                      <p className="text-sm text-blue-600">{group.concurso}</p>
                    </Card>
                  ))}
                </div>
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>

      {/* Comments Dialog */}
      {selectedPost && (
        <Dialog open={!!selectedPost} onOpenChange={() => setSelectedPost(null)}>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Comentários</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="border-b pb-4">
                <p className="font-semibold">{selectedPost.user_name}</p>
                <p className="text-gray-700">{selectedPost.content}</p>
              </div>

              <div className="space-y-3">
                {comments.map((comment) => (
                  <div key={comment.id} className="flex gap-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-blue-600 text-sm font-semibold">{comment.user_name[0].toUpperCase()}</span>
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold text-sm">{comment.user_name}</p>
                      <p className="text-gray-700 text-sm">{comment.content}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex gap-2 pt-4 border-t">
                <Input
                  data-testid="comment-input"
                  placeholder="Escreva um comentário..."
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && addComment()}
                />
                <Button data-testid="submit-comment-btn" onClick={addComment}>Enviar</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default Social;