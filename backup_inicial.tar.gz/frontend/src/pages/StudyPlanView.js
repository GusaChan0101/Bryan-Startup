import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Plus, Calendar, Trash2, PlayCircle, CheckCircle, XCircle, ChevronRight } from 'lucide-react';
import axios from 'axios';
import { API } from '@/App';
import { toast } from 'sonner';

const StudyPlanView = ({ user }) => {
  const [plans, setPlans] = useState([]);
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [currentLesson, setCurrentLesson] = useState(null);
  const [lessonProgress, setLessonProgress] = useState({});
  const [userAnswers, setUserAnswers] = useState({});
  const [showResult, setShowResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showPlanDialog, setShowPlanDialog] = useState(false);
  const [deleteItem, setDeleteItem] = useState(null);

  const [planForm, setPlanForm] = useState({
    subject: '',
    exam_date: '',
    daily_hours: 4,
    difficulty_level: 'intermediario',
    banca: '',
    escolaridade: 'medio',
    finalidade: ''
  });

  const token = localStorage.getItem('token');

  useEffect(() => {
    loadPlans();
  }, []);

  useEffect(() => {
    if (selectedPlan) {
      loadProgress();
    }
  }, [selectedPlan]);

  const loadPlans = async () => {
    try {
      const response = await axios.get(`${API}/study-plans${token ? `?token=${token}` : ''}`);
      setPlans(response.data);
    } catch (error) {
      console.error('Erro:', error);
    }
  };

  const loadProgress = async () => {
    if (!user || !selectedPlan) return;
    try {
      const response = await axios.get(`${API}/lesson-progress/${selectedPlan.id}?token=${token}`);
      const progressMap = {};
      response.data.forEach(p => {
        progressMap[p.lesson_id] = p;
      });
      setLessonProgress(progressMap);
    } catch (error) {
      console.error('Erro:', error);
    }
  };

  const createPlan = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      await axios.post(
        `${API}/ai/create-study-plan${token ? `?token=${token}` : ''}`,
        planForm
      );
      toast.success('Cronograma criado! Gerando aulas...');
      setShowPlanDialog(false);
      await loadPlans();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Erro');
    } finally {
      setLoading(false);
    }
  };

  const deletePlan = async () => {
    if (!deleteItem) return;
    try {
      await axios.delete(`${API}/study-plans/${deleteItem.id}${token ? `?token=${token}` : ''}`);
      toast.success('Deletado!');
      await loadPlans();
      if (selectedPlan?.id === deleteItem.id) {
        setSelectedPlan(null);
      }
    } catch (error) {
      toast.error('Erro');
    } finally {
      setDeleteItem(null);
    }
  };

  const startLesson = (lesson) => {
    const progress = lessonProgress[lesson.id];
    
    // Check if previous lesson is completed
    const lessonIndex = selectedPlan.lessons.findIndex(l => l.id === lesson.id);
    if (lessonIndex > 0) {
      const prevLesson = selectedPlan.lessons[lessonIndex - 1];
      const prevProgress = lessonProgress[prevLesson.id];
      if (!prevProgress || !prevProgress.completed) {
        toast.error('Complete a aula anterior primeiro!');
        return;
      }
    }

    setCurrentLesson(lesson);
    setUserAnswers({});
    setShowResult(null);
  };

  const submitAnswers = async () => {
    if (Object.keys(userAnswers).length !== currentLesson.questions.length) {
      toast.error('Responda todas as questões!');
      return;
    }

    setLoading(true);

    try {
      const answers = currentLesson.questions.map((_, index) => ({
        answer: userAnswers[index]
      }));

      const response = await axios.post(
        `${API}/lesson/submit?plan_id=${selectedPlan.id}${token ? `&token=${token}` : ''}`,
        {
          lesson_id: currentLesson.id,
          answers
        }
      );

      setShowResult(response.data);
      
      if (response.data.passed) {
        toast.success('Parabéns! Avançando para próxima aula...');
        await loadProgress();
      } else if (response.data.attempts >= 3) {
        toast.warning('Respostas corretas exibidas. Estude e tente novamente!');
      } else {
        toast.error(`Tente novamente! Tentativa ${response.data.attempts}/3`);
      }
    } catch (error) {
      toast.error('Erro');
    } finally {
      setLoading(false);
    }
  };

  const nextLesson = () => {
    const currentIndex = selectedPlan.lessons.findIndex(l => l.id === currentLesson.id);
    if (currentIndex < selectedPlan.lessons.length - 1) {
      startLesson(selectedPlan.lessons[currentIndex + 1]);
    } else {
      setCurrentLesson(null);
      toast.success('Parabéns! Você completou todas as aulas!');
    }
  };

  if (currentLesson) {
    return (
      <div className="max-w-4xl mx-auto">
        <Button
          variant="outline"
          onClick={() => setCurrentLesson(null)}
          className="mb-4"
        >
          ← Voltar ao Cronograma
        </Button>

        <Card className="p-6">
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">{currentLesson.title}</h2>
            <p className="text-gray-600">Dia {currentLesson.day} | {selectedPlan.subject}</p>
          </div>

          {/* Video */}
          {currentLesson.video_url && (
            <div className="mb-6 aspect-video bg-gray-100 rounded-lg overflow-hidden">
              <iframe
                src={currentLesson.video_url.replace('watch?v=', 'embed/')}
                className="w-full h-full"
                allowFullScreen
                title={currentLesson.title}
              />
            </div>
          )}

          {/* Summary */}
          <div className="mb-6 p-4 bg-blue-50 rounded-lg">
            <h3 className="font-semibold text-lg mb-2 text-gray-900">Resumo</h3>
            <p className="text-gray-700">{currentLesson.summary}</p>
          </div>

          {/* Detailed Content */}
          <div className="mb-6 p-4 bg-gray-50 rounded-lg">
            <h3 className="font-semibold text-lg mb-3 text-gray-900">Conteúdo Detalhado</h3>
            <div className="prose max-w-none text-gray-700 whitespace-pre-wrap">
              {currentLesson.detailed_content}
            </div>
          </div>

          {/* Questions */}
          <div className="mb-6">
            <h3 className="font-semibold text-xl mb-4 text-gray-900">Questionário</h3>
            <p className="text-sm text-gray-600 mb-4">
              Você deve acertar todas as questões para avançar. {lessonProgress[currentLesson.id]?.attempts || 0}/3 tentativas
            </p>

            {currentLesson.questions.map((q, index) => (
              <div key={index} className="question-card mb-4">
                <h4 className="font-semibold mb-3">
                  {index + 1}. {q.question}
                </h4>
                <div className="space-y-2">
                  {q.options.map((option, optIndex) => {
                    const isSelected = userAnswers[index] === option[0];
                    const showAnswers = showResult?.show_answers;
                    const isCorrect = option[0] === q.correct_answer;
                    
                    return (
                      <button
                        key={optIndex}
                        disabled={showResult?.passed || loading}
                        className={`option-button ${
                          isSelected ? 'selected' : ''
                        } ${
                          showAnswers && isCorrect ? 'correct' : ''
                        }`}
                        onClick={() => {
                          if (!showResult?.passed) {
                            setUserAnswers({ ...userAnswers, [index]: option[0] });
                          }
                        }}
                      >
                        {option}
                        {showAnswers && isCorrect && (
                          <CheckCircle className="inline-block ml-2 w-5 h-5 text-green-600" />
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>

          {/* Actions */}
          {!showResult?.passed ? (
            <Button
              onClick={submitAnswers}
              className="w-full bg-blue-600 hover:bg-blue-700 py-6 text-lg"
              disabled={loading || Object.keys(userAnswers).length !== currentLesson.questions.length}
            >
              {loading ? 'Verificando...' : 'Enviar Respostas'}
            </Button>
          ) : (
            <Button
              onClick={nextLesson}
              className="w-full bg-green-600 hover:bg-green-700 py-6 text-lg"
            >
              Próxima Aula <ChevronRight className="inline ml-2" />
            </Button>
          )}

          {/* Result */}
          {showResult && (
            <Card className="mt-4 p-4 text-center">
              <div className="mb-2">
                {showResult.passed ? (
                  <CheckCircle className="w-12 h-12 text-green-600 mx-auto" />
                ) : (
                  <XCircle className="w-12 h-12 text-red-600 mx-auto" />
                )}
              </div>
              <p className="text-xl font-bold mb-2">
                {showResult.passed ? 'Aprovado!' : 'Não passou'}
              </p>
              <p className="text-gray-600">
                Você acertou {showResult.correct} de {showResult.total}
              </p>
              {!showResult.passed && (
                <p className="text-sm text-gray-500 mt-2">
                  {showResult.show_answers 
                    ? 'Respostas corretas exibidas acima'
                    : `Tente novamente! (${showResult.attempts}/3 tentativas)`}
                </p>
              )}
            </Card>
          )}
        </Card>
      </div>
    );
  }

  if (selectedPlan) {
    return (
      <div>
        <Button
          variant="outline"
          onClick={() => {
            setSelectedPlan(null);
            setLessonProgress({});
          }}
          className="mb-4"
        >
          ← Voltar aos Cronogramas
        </Button>

        <Card className="p-6 mb-6">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">{selectedPlan.subject}</h2>
          <div className="grid md:grid-cols-2 gap-4 text-sm text-gray-600">
            <div><strong>Finalidade:</strong> {selectedPlan.finalidade}</div>
            <div><strong>Banca:</strong> {selectedPlan.banca}</div>
            <div><strong>Escolaridade:</strong> {selectedPlan.escolaridade}</div>
            <div><strong>Data Alvo:</strong> {selectedPlan.exam_date}</div>
            <div><strong>Horas/dia:</strong> {selectedPlan.daily_hours}h</div>
            <div><strong>Nível:</strong> {selectedPlan.difficulty_level}</div>
          </div>
        </Card>

        <h3 className="text-2xl font-bold text-gray-900 mb-4">Aulas</h3>
        <div className="grid gap-4">
          {selectedPlan.lessons.map((lesson, index) => {
            const progress = lessonProgress[lesson.id];
            const isCompleted = progress?.completed;
            const canStart = index === 0 || lessonProgress[selectedPlan.lessons[index - 1]?.id]?.completed;
            
            return (
              <Card
                key={lesson.id}
                className={`p-4 ${
                  isCompleted ? 'bg-green-50 border-green-300' : 'bg-white'
                } ${!canStart ? 'opacity-50' : ''}`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3">
                      {isCompleted ? (
                        <CheckCircle className="w-6 h-6 text-green-600" />
                      ) : (
                        <PlayCircle className="w-6 h-6 text-blue-600" />
                      )}
                      <div>
                        <h4 className="font-semibold text-lg text-gray-900">
                          Dia {lesson.day}: {lesson.title}
                        </h4>
                        {progress && (
                          <p className="text-sm text-gray-600">
                            Tentativas: {progress.attempts} | Score: {progress.score}%
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                  <Button
                    onClick={() => startLesson(lesson)}
                    disabled={!canStart}
                    variant={isCompleted ? 'outline' : 'default'}
                  >
                    {isCompleted ? 'Revisar' : canStart ? 'Iniciar' : 'Bloqueado'}
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-6 flex justify-between items-center">
        <h2 className="text-3xl font-bold text-gray-900">Meus Cronogramas</h2>
        <Dialog open={showPlanDialog} onOpenChange={setShowPlanDialog}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              Novo Cronograma
            </Button>
          </DialogTrigger>
          <DialogContent className="max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Criar Cronograma com Aulas</DialogTitle>
            </DialogHeader>
            <form onSubmit={createPlan} className="space-y-4">
              <div>
                <Label>Assunto/Objetivo</Label>
                <Input
                  placeholder="Ex: Matemática para ENEM"
                  value={planForm.subject}
                  onChange={(e) => setPlanForm({ ...planForm, subject: e.target.value })}
                  required
                  className="mt-2"
                />
              </div>
              <div>
                <Label>Finalidade</Label>
                <Input
                  placeholder="Para que é esse cronograma?"
                  value={planForm.finalidade}
                  onChange={(e) => setPlanForm({ ...planForm, finalidade: e.target.value })}
                  required
                  className="mt-2"
                />
              </div>
              <div>
                <Label>Banca (opcional)</Label>
                <Input
                  placeholder="Ex: CESPE, FCC"
                  value={planForm.banca}
                  onChange={(e) => setPlanForm({ ...planForm, banca: e.target.value })}
                  className="mt-2"
                />
              </div>
              <div>
                <Label>Escolaridade</Label>
                <Select
                  value={planForm.escolaridade}
                  onValueChange={(value) => setPlanForm({ ...planForm, escolaridade: value })}
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="fundamental">Fundamental</SelectItem>
                    <SelectItem value="medio">Médio</SelectItem>
                    <SelectItem value="tecnico">Técnico</SelectItem>
                    <SelectItem value="superior">Superior</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Data Alvo</Label>
                <Input
                  type="date"
                  value={planForm.exam_date}
                  onChange={(e) => setPlanForm({ ...planForm, exam_date: e.target.value })}
                  required
                  className="mt-2"
                />
              </div>
              <div>
                <Label>Horas por Dia</Label>
                <Input
                  type="number"
                  min="1"
                  max="12"
                  value={planForm.daily_hours}
                  onChange={(e) => setPlanForm({ ...planForm, daily_hours: parseInt(e.target.value) })}
                  className="mt-2"
                />
              </div>
              <div>
                <Label>Nível</Label>
                <Select
                  value={planForm.difficulty_level}
                  onValueChange={(value) => setPlanForm({ ...planForm, difficulty_level: value })}
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="iniciante">Iniciante</SelectItem>
                    <SelectItem value="intermediario">Intermediário</SelectItem>
                    <SelectItem value="avancado">Avançado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700"
                disabled={loading}
              >
                {loading ? 'Criando...' : 'Criar Cronograma'}
              </Button>
              <p className="text-xs text-gray-500 text-center">
                A IA criará 4+ aulas por dia com vídeos, conteúdo e questionários
              </p>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {plans.map((plan) => (
          <Card key={plan.id} className="p-4 hover:shadow-lg transition-shadow">
            <div className="flex items-start justify-between mb-3">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Calendar className="w-6 h-6 text-blue-600" />
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setDeleteItem(plan)}
              >
                <Trash2 className="w-4 h-4 text-red-500" />
              </Button>
            </div>
            <h3 className="text-xl font-semibold mb-2 text-gray-900">{plan.subject}</h3>
            <p className="text-sm text-gray-600 mb-2">{plan.finalidade}</p>
            <p className="text-sm text-gray-500 mb-3">
              {plan.lessons?.length || 0} aulas | {plan.exam_date}
            </p>
            <Button
              onClick={() => setSelectedPlan(plan)}
              className="w-full bg-blue-600 hover:bg-blue-700"
            >
              Abrir Curso
            </Button>
          </Card>
        ))}
      </div>

      {/* Delete Dialog */}
      <AlertDialog open={!!deleteItem} onOpenChange={() => setDeleteItem(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja deletar "{deleteItem?.subject}"? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={deletePlan}
              className="bg-red-600 hover:bg-red-700"
            >
              Deletar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default StudyPlanView;