import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Heart, Copy, Edit } from 'lucide-react';
import axios from 'axios';
import { API } from '@/App';
import { toast } from 'sonner';

const Support = () => {
  const [config, setConfig] = useState({ pix_key: null, pix_qr_code: null });
  const [editing, setEditing] = useState(false);
  const [pixKey, setPixKey] = useState('');

  useEffect(() => {
    loadConfig();
  }, []);

  const loadConfig = async () => {
    try {
      const response = await axios.get(`${API}/config`);
      setConfig(response.data);
      setPixKey(response.data.pix_key || '');
    } catch (error) {
      console.error('Erro ao carregar config:', error);
    }
  };

  const copyPixKey = () => {
    if (config.pix_key) {
      navigator.clipboard.writeText(config.pix_key);
      toast.success('Chave PIX copiada!');
    }
  };

  return (
    <div className="max-w-2xl mx-auto" data-testid="support-container">
      <Card className="p-8 text-center">
        <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <Heart className="w-8 h-8 text-red-600" />
        </div>
        
        <h2 className="text-3xl font-bold text-gray-900 mb-2">
          Apoie os Desenvolvedores
        </h2>
        
        <p className="text-gray-600 mb-6">
          Este projeto foi criado com dedicação por <strong>Bryan Menezes</strong> e <strong>Josué Oliveira</strong>.
          Sua contribuição ajuda a manter e melhorar a plataforma!
        </p>

        {config.pix_key ? (
          <div className="space-y-4">
            {config.pix_qr_code && (
              <div className="bg-white p-4 rounded-lg inline-block">
                <img 
                  src={config.pix_qr_code} 
                  alt="QR Code PIX"
                  className="w-64 h-64 mx-auto"
                />
              </div>
            )}
            
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600 mb-2">Chave PIX</p>
              <div className="flex items-center justify-center gap-2">
                <code className="text-lg font-mono text-gray-900">{config.pix_key}</code>
                <Button
                  data-testid="copy-pix-btn"
                  size="sm"
                  variant="outline"
                  onClick={copyPixKey}
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-blue-50 p-6 rounded-lg">
            <p className="text-gray-700 mb-4">
              A chave PIX será adicionada em breve pelos desenvolvedores.
            </p>
            <p className="text-sm text-gray-500">
              Obrigado pelo interesse em apoiar o projeto! 💙
            </p>
          </div>
        )}

        <div className="mt-8 pt-6 border-t">
          <p className="text-sm text-gray-500">
            Qualquer valor é muito bem-vindo e nos motiva a continuar desenvolvendo!
          </p>
        </div>
      </Card>
    </div>
  );
};

export default Support;
